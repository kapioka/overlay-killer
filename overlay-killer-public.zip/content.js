(() => {
  "use strict";

  const DEFAULT_SETTINGS = {
    signalSize: true,
    signalTag: true,
    signalPosition: false,
    signalVocab: true,
    signalAttribute: true,
    scoreThreshold: 4,
    maxNormalRemovals: 6,
    enableEdgeBanner: true,
    enableStructEdgeAds: true,
    enableEdgeOverlap: true,
    edgeOverlapThreshold: 0.15,
    enableEdgeClickableHint: true,
    enableEdgeStackingGuard: true,
    enableEdgeVocabHint: true,
    enableEdgeAttributeHint: true,
    edgeStructThreshold: 5,
    edgeStructMaxRemove: 2,
    edgeMaxHeightRatio: 0.35,
    enableOverlay: true,
    debugLogs: false
  };

  const CORE_VOCAB = [
    "ad",
    "ads",
    "advert",
    "advertisement",
    "advertising",
    "adframe",
    "adslot",
    "adservice",
    "adsense",
    "adsbygoogle",
    "sponsor",
    "sponsored",
    "promo",
    "promoted",
    "doubleclick",
    "taboola",
    "outbrain"
  ];
  const CORE_HOST_HINTS = [
    "adclick.g.doubleclick.net",
    "googleads.g.doubleclick.net",
    "doubleclick.net",
    "googlesyndication.com",
    "pagead2.googlesyndication.com",
    "tpc.googlesyndication.com",
    "securepubads.g.doubleclick.net",
    "cdn.adpushup.com",
    "adpushup.com"
  ];

  const OVERLAY_MIN_Z_INDEX = 900;
  const EDGE_MIN_Z_INDEX = 500;
  const EDGE_MARGIN = 8;
  const EDGE_MIN_HEIGHT_PX = 40;
  const STACKING_SCAN_MAX_DEPTH = 12;
  const MAX_OVERLAY_SCAN = 12;
  const INLINE_TEXT_LIMIT = 160;
  const MAX_INLINE_REMOVE = 6;
  const MAX_SIDE_RAIL_REMOVE = 4;
  const ARTICLE_MARKER_SELECTOR = "article, [itemprop='articleBody'], .entry-content, .post-content, .article-body, .entry, .post, .post-body, .post-main, .post-inner, .article-content, .article-main, .entry-main, .single-post, .archive-list";
  const ARTICLE_STRUCTURE_SELECTOR = "article, h1, h2, h3, h4, p, time, ul, ol, li, blockquote";

  const HIDDEN_ATTR = "data-ok-hidden";
  const SHADOW_PATCH_ATTR = "__okAttachShadowPatched";
  const shadowRoots = new Set();
  const actionHistory = [];
  let cachedPackagedVocab = null;
  let shadowTrackingReady = false;
  let activeBatch = null;

  function log(enabled, ...args) {
    if (!enabled) return;
    console.log("[OverlayKiller]", ...args);
  }

  function parseNumber(value, fallback) {
    const n = Number(value);
    return Number.isFinite(n) ? n : fallback;
  }

  function parseZIndex(value) {
    if (value === undefined || value === null) return null;
    const s = String(value).trim().toLowerCase();
    if (!s || s === "auto") return null;
    const n = Number.parseInt(s, 10);
    return Number.isFinite(n) ? n : null;
  }

  function getRectArea(rect) {
    return Math.max(0, rect.width) * Math.max(0, rect.height);
  }

  function getViewportArea() {
    return Math.max(1, window.innerWidth * window.innerHeight);
  }

  function isElementVisible(el) {
    if (!(el instanceof Element)) return false;
    const style = getComputedStyle(el);
    if (style.display === "none" || style.visibility === "hidden") return false;
    if (Number.parseFloat(style.opacity || "1") < 0.03) return false;
    const rect = el.getBoundingClientRect();
    if (rect.width < 4 || rect.height < 4) return false;
    return true;
  }

  function shouldSkipForRemoval(el) {
    if (!(el instanceof Element)) return true;
    const tag = el.tagName;
    return tag === "VIDEO" || tag === "CANVAS" || tag === "SCRIPT" || tag === "STYLE";
  }

  function isNearVideoOrCanvas(el) {
    if (!(el instanceof Element)) return false;
    if (el.querySelector("video, canvas")) return true;

    let node = el.parentElement;
    let depth = 0;
    while (node && depth < 2) {
      if (node.querySelector("video, canvas")) return true;
      node = node.parentElement;
      depth += 1;
    }
    return false;
  }

  function isAdVideoContainer(el) {
    if (!(el instanceof Element)) return false;
    const hasVideo = Boolean(el.querySelector("video, iframe"));
    if (!hasVideo) return false;

    const clsId = `${el.id || ""} ${(el.className || "").toString()}`.toLowerCase();
    const style = getComputedStyle(el);
    return (
      hasDirectAdSignature(el) ||
      hasAttributeSignal(el) ||
      hasDismissControl(el) ||
      /ima-ad-container|videowrapperdiv|apclosebutton|ap-player|adswift|side-rail-dismiss-btn/.test(clsId) ||
      ((style.position === "fixed" || style.position === "sticky") && parseNumber(style.zIndex, 0) >= 999)
    );
  }

  function beginBatch(label) {
    activeBatch = {
      label,
      hidden: [],
      scrollLocks: []
    };
  }

  function finalizeBatch() {
    if (!activeBatch) return false;
    const hasActions = activeBatch.hidden.length > 0 || activeBatch.scrollLocks.length > 0;
    if (hasActions) {
      actionHistory.push(activeBatch);
      if (actionHistory.length > 20) actionHistory.shift();
    }
    activeBatch = null;
    return hasActions;
  }

  function recordScrollState(el, prop, value) {
    if (!(el instanceof Element) || !activeBatch) return;
    const already = activeBatch.scrollLocks.some((item) => item.el === el && item.prop === prop);
    if (already) return;
    activeBatch.scrollLocks.push({ el, prop, value });
  }

  function recordAndHide(el, reason = "unknown") {
    if (!(el instanceof Element)) return false;
    if (el.hasAttribute(HIDDEN_ATTR)) return false;

    const prevStyle = el.getAttribute("style");
    const prevAria = el.getAttribute("aria-hidden");

    el.style.setProperty("display", "none", "important");
    el.setAttribute("aria-hidden", "true");
    el.setAttribute(HIDDEN_ATTR, "1");

    if (activeBatch) {
      activeBatch.hidden.push({ el, prevStyle, prevAria, reason });
    }
    return true;
  }

  function undoLast() {
    const batch = actionHistory.pop();
    if (!batch) return { ok: false, detail: "undo-empty" };

    let restored = 0;
    for (let i = batch.scrollLocks.length - 1; i >= 0; i -= 1) {
      const item = batch.scrollLocks[i];
      if (!(item.el instanceof Element) || !item.el.isConnected) continue;
      if (item.value) {
        item.el.style.setProperty(item.prop, item.value, "important");
      } else {
        item.el.style.removeProperty(item.prop);
      }
    }

    for (let i = batch.hidden.length - 1; i >= 0; i -= 1) {
      const item = batch.hidden[i];
      const { el, prevStyle, prevAria } = item;
      if (!(el instanceof Element) || !el.isConnected) continue;

      if (prevStyle !== null) {
        el.setAttribute("style", prevStyle);
      } else {
        el.removeAttribute("style");
      }

      if (prevAria !== null) {
        el.setAttribute("aria-hidden", prevAria);
      } else {
        el.removeAttribute("aria-hidden");
      }

      el.removeAttribute(HIDDEN_ATTR);
      restored += 1;
    }

    return { ok: restored > 0 || batch.scrollLocks.length > 0, detail: "undo-restored", restored };
  }

  function clearScrollLock() {
    const html = document.documentElement;
    const body = document.body;
    for (const el of [html, body]) {
      if (!(el instanceof Element)) continue;
      const style = getComputedStyle(el);
      if (style.overflow === "hidden") {
        recordScrollState(el, "overflow", el.style.getPropertyValue("overflow"));
        el.style.setProperty("overflow", "auto", "important");
      }
    }
  }

  function registerShadowRoot(sr) {
    if (!sr || shadowRoots.has(sr)) return;
    shadowRoots.add(sr);
  }

  function scanOpenShadowRoots(rootNode) {
    if (!rootNode) return;
    const walker = document.createTreeWalker(rootNode, NodeFilter.SHOW_ELEMENT);
    let node = walker.currentNode;
    while (node) {
      const el = node;
      if (el.shadowRoot) registerShadowRoot(el.shadowRoot);
      node = walker.nextNode();
    }
  }

  function setupShadowTracking() {
    if (shadowTrackingReady) return;
    shadowTrackingReady = true;

    const original = Element.prototype.attachShadow;
    if (!Element.prototype[SHADOW_PATCH_ATTR]) {
      Element.prototype.attachShadow = function attachShadowPatched(init) {
        const sr = original.call(this, init);
        if (init && init.mode === "open") registerShadowRoot(sr);
        return sr;
      };
      Object.defineProperty(Element.prototype, SHADOW_PATCH_ATTR, {
        value: true,
        configurable: false,
        writable: false,
        enumerable: false
      });
    }

    scanOpenShadowRoots(document);
  }

  function collectAllElements() {
    setupShadowTracking();
    scanOpenShadowRoots(document);

    const elements = [];
    if (document.body) elements.push(...document.body.querySelectorAll("*"));

    for (const sr of shadowRoots) {
      try {
        if (sr && sr.host && sr.isConnected) {
          elements.push(...sr.querySelectorAll("*"));
        }
      } catch (_error) {
        // ignore detached roots
      }
    }
    return elements;
  }

  function tokenize(value) {
    return (value || "")
      .toLowerCase()
      .split(/[^a-z0-9]+/)
      .map((v) => v.trim())
      .filter((v) => v.length >= 2 && v.length <= 40);
  }


  function normalizeHostHint(value) {
    const raw = (value || "").trim().toLowerCase();
    if (!raw) return null;
    const withoutScheme = raw.replace(/^https?:\/\//, "");
    const cleaned = withoutScheme.replace(/^[|]+/, "").replace(/[\^*]+$/g, "");
    return cleaned || null;
  }

  function isHostLikeHint(value) {
    const normalized = normalizeHostHint(value);
    return Boolean(normalized && /(?:^|\.)[a-z0-9-]+\.[a-z]{2,}/.test(normalized));
  }

  function extractUrlHost(value) {
    const normalized = normalizeHostHint(value);
    if (!normalized) return null;
    try {
      const url = normalized.startsWith("http://") || normalized.startsWith("https://") ? new URL(normalized) : new URL(`https://${normalized}`);
      return (url.host || "").toLowerCase();
    } catch (_error) {
      const host = normalized.split("/")[0] || "";
      return host.toLowerCase() || null;
    }
  }

  function collectUrlLikeValues(el) {
    if (!(el instanceof Element)) return [];
    const values = [];
    const pushValue = (v) => {
      if (!v) return;
      values.push(v);
    };

    pushValue(el.getAttribute("src") || "");
    pushValue(el.getAttribute("href") || "");
    for (const attr of el.getAttributeNames()) {
      pushValue(el.getAttribute(attr) || "");
    }

    const descendants = el.querySelectorAll("a[href], iframe[src], img[src], video[src], script[src], source[src]");
    for (const node of descendants) {
      pushValue(node.getAttribute("href") || "");
      pushValue(node.getAttribute("src") || "");
      for (const attr of node.getAttributeNames()) {
        pushValue(node.getAttribute(attr) || "");
      }
    }
    return values;
  }

  function findCloseButton(target) {
    const selectors = [
      "button[aria-label*='close' i]",
      "button[aria-label*='閉じ' i]",
      "button[title*='close' i]",
      "button[title*='閉じ' i]",
      "[role='button'][aria-label*='close' i]",
      "[role='button'][aria-label*='閉じ' i]",
      "button[class*='close' i]",
      "[role='button'][class*='close' i]",
      "button",
      "[role='button']",
      "a"
    ];

    const hintWords = ["close", "閉じ", "dismiss", "cancel", "×", "✕", "✖"];

    for (const selector of selectors) {
      const nodes = target.querySelectorAll(selector);
      for (const node of nodes) {
        if (!(node instanceof HTMLElement)) continue;
        if (!isElementVisible(node)) continue;

        const text = (node.textContent || "").toLowerCase();
        const aria = (node.getAttribute("aria-label") || "").toLowerCase();
        const title = (node.getAttribute("title") || "").toLowerCase();
        const cls = (node.className || "").toString().toLowerCase();

        const matched = hintWords.some((w) => text.includes(w) || aria.includes(w) || title.includes(w) || cls.includes(w));
        if (matched) return node;
      }
    }

    return null;
  }

  function findCollapseControl(target) {
    const selectors = [
      "button",
      "[role='button']",
      "a",
      "summary"
    ];
    const arrowChars = ["▼", "▲", "◀", "▶", "▾", "▴", "‹", "›", "«", "»", "∨", "∧"];
    const hintWords = ["collapse", "minimize", "minimise", "hide", "toggle", "slide", "drawer", "close", "閉じ", "隠", "しま", "収納"];

    for (const selector of selectors) {
      const nodes = target.querySelectorAll(selector);
      for (const node of nodes) {
        if (!(node instanceof HTMLElement)) continue;
        if (!isElementVisible(node)) continue;

        const text = (node.textContent || "").trim();
        const aria = (node.getAttribute("aria-label") || "").toLowerCase();
        const title = (node.getAttribute("title") || "").toLowerCase();
        const cls = (node.className || "").toString().toLowerCase();
        const matchedWord = hintWords.some((w) => aria.includes(w) || title.includes(w) || cls.includes(w));
        const matchedArrow = arrowChars.includes(text) || (text.length <= 2 && [...text].some((ch) => arrowChars.includes(ch)));
        if (matchedWord || matchedArrow) return node;
      }
    }

    return null;
  }


  function hasDismissControl(target) {
    return Boolean(findCloseButton(target) || findCollapseControl(target));
  }

  function isDockedEdgePosition(rect) {
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const nearBottom = rect.bottom >= vh - 24;
    const nearTop = rect.top <= 24;
    const nearLeft = rect.left <= 24;
    const nearRight = rect.right >= vw - 24;
    const bottomTopBand = (nearBottom || nearTop) && rect.width >= vw * 0.28 && rect.height >= 50 && rect.height <= vh * 0.45;
    const sideBand = (nearLeft || nearRight) && rect.height >= vh * 0.24 && rect.width >= 80 && rect.width <= vw * 0.45;
    const cornerFloat = nearBottom && (nearLeft || nearRight) && rect.width >= 120 && rect.width <= vw * 0.22 && rect.height >= 90 && rect.height <= vh * 0.28;
    return { nearBottom, nearTop, nearLeft, nearRight, matched: bottomTopBand || sideBand || cornerFloat, bottomTopBand, sideBand, cornerFloat };
  }


  function isSideRailPosition(rect, mainRect) {
    if (!rect || !mainRect) return false;
    const vw = window.innerWidth;
    const horizontalGap = Math.max(16, vw * 0.02);
    const leftRail = rect.right <= mainRect.left - horizontalGap;
    const rightRail = rect.left >= mainRect.right + horizontalGap;
    const verticallyAligned = rect.bottom >= mainRect.top - 120 && rect.top <= mainRect.bottom + 120;
    const edgeAnchored = rect.left <= 64 || rect.right >= vw - 64;
    return (leftRail || rightRail || edgeAnchored) && verticallyAligned;
  }

  function hasSizeSignal(el, rect) {
    const w = rect.width;
    const h = rect.height;
    const area = getRectArea(rect);

    const near = (a, b, tolerance) => Math.abs(a - b) <= tolerance;
    const matchClassic =
      (near(w, 300, 36) && near(h, 250, 30)) ||
      (near(w, 320, 36) && near(h, 100, 28)) ||
      (near(w, 728, 72) && near(h, 90, 24)) ||
      (near(w, 970, 96) && near(h, 250, 40)) ||
      (near(w, 160, 24) && near(h, 600, 80));

    const matchAreaBand = area >= 12000 && area <= 220000;
    return matchClassic || matchAreaBand;
  }

  function hasTagSignal(el) {
    const tag = el.tagName;
    return tag === "IFRAME" || tag === "INS" || tag === "ASIDE";
  }

  function hasPositionSignal(el, rect) {
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const rightRail = rect.left >= vw * 0.6 && rect.width <= vw * 0.42;
    const inMiddle = rect.top >= vh * 0.12 && rect.top <= vh * 0.88;
    const medium = rect.width <= vw * 0.96 && rect.height <= vh * 0.45;
    const articleLike = Boolean(el.closest("article, main, [role='main']"));
    return rightRail || (articleLike && inMiddle && medium);
  }

  function hasAttributeSignal(el) {
    const ariaLabel = (el.getAttribute("aria-label") || "").toLowerCase();
    const role = (el.getAttribute("role") || "").toLowerCase();
    if (ariaLabel.includes("advertisement") || ariaLabel.includes("sponsored")) return true;
    if (role.includes("complementary") && ariaLabel.includes("ad")) return true;

    for (const attr of el.getAttributeNames()) {
      const n = attr.toLowerCase();
      const v = (el.getAttribute(attr) || "").toLowerCase();
      if (n.startsWith("data-ad") || n.includes("sponsor") || v.includes("adsbygoogle")) return true;
    }
    return false;
  }

  function hasVocabSignal(el, vocabSet) {
    if (!vocabSet || vocabSet.size === 0) return false;

    const parts = [];
    parts.push(el.id || "");
    parts.push((el.className || "").toString());
    parts.push(el.getAttribute("aria-label") || "");
    parts.push(el.getAttribute("name") || "");
    parts.push(el.getAttribute("src") || "");
    parts.push(el.getAttribute("href") || "");

    for (const attr of el.getAttributeNames()) {
      if (attr.startsWith("data-") || attr.includes("ad") || attr.includes("sponsor")) {
        parts.push(attr);
        parts.push(el.getAttribute(attr) || "");
      }
    }

    const joined = parts.join(" ").toLowerCase();
    const tokens = tokenize(joined);
    return tokens.some((t) => vocabSet.has(t));
  }

  function hasDirectAdSignature(el) {
    if (!(el instanceof Element)) return false;
    const directPatterns = [
      "googleads",
      "adchoices",
      "adsystem",
      "doubleclick",
      "googlesyndication",
      "adsbygoogle",
      "pagead2",
      "securepubads",
      "adservice",
      "adserver",
      "adpushup",
      "ima-ad-container",
      "apclosebutton",
      "ap-float-close-btn",
      "videowrapperdiv",
      "adswift",
      "side-rail-dismiss-btn",
      "side-rail-edge",
      "doubleclick.net/pagead"
    ];

    const parts = [];
    parts.push(el.id || "");
    parts.push((el.className || "").toString());
    parts.push(el.getAttribute("src") || "");
    parts.push(el.getAttribute("href") || "");
    parts.push(el.getAttribute("aria-label") || "");

    for (const attr of el.getAttributeNames()) {
      parts.push(attr);
      parts.push(el.getAttribute(attr) || "");
    }

    const joined = parts.join(" ").toLowerCase();
    return directPatterns.some((pattern) => joined.includes(pattern));
  }


  function hasAdHostSignal(el, hostHints) {
    if (!(el instanceof Element) || !(hostHints instanceof Set) || hostHints.size === 0) return false;
    const hosts = new Set();
    for (const value of collectUrlLikeValues(el)) {
      const host = extractUrlHost(value);
      if (host) hosts.add(host);
    }
    for (const host of hosts) {
      for (const hint of hostHints) {
        if (host === hint || host.endsWith(`.${hint}`) || hint.endsWith(`.${host}`)) {
          return true;
        }
      }
    }
    return false;
  }


  function getAbsoluteAdLinkBundleInfo(el, hostHints) {
    if (!(el instanceof Element)) return { matched: false, score: 0, container: null };
    const links = Array.from(el.querySelectorAll("a[href]")).filter((link) => link instanceof Element);
    if (links.length < 3) return { matched: false, score: 0, container: null };

    let absoluteCount = 0;
    let hostMatched = 0;
    let targetBlank = 0;
    const sizeBuckets = new Map();

    for (const link of links) {
      const style = getComputedStyle(link);
      const rect = link.getBoundingClientRect();
      if (rect.width < 80 || rect.height < 60) continue;
      if (style.position === "absolute" || style.position === "fixed") {
        absoluteCount += 1;
      }
      if ((link.getAttribute("target") || "").toLowerCase() === "_blank") {
        targetBlank += 1;
      }
      if (hasDirectAdSignature(link) || hasAdHostSignal(link, hostHints)) {
        hostMatched += 1;
      }
      const key = `${Math.round(rect.width / 12)}x${Math.round(rect.height / 12)}`;
      sizeBuckets.set(key, (sizeBuckets.get(key) || 0) + 1);
    }

    const maxBucket = Math.max(0, ...sizeBuckets.values());
    const clsId = `${el.id || ""} ${(el.className || "").toString()}`.toLowerCase();
    const offerLike = /alloffers|offer-container|offer\d+|price-set|banner-clickholder/.test(clsId);
    const matched = hostMatched >= 3 && absoluteCount >= 3 && (maxBucket >= 3 || targetBlank >= 3 || offerLike);
    let score = 0;
    if (matched) {
      score += 4;
      if (offerLike) score += 2;
      if (targetBlank >= 3) score += 1;
      if (maxBucket >= 4) score += 1;
    }
    return { matched, score, container: matched ? el : null };
  }

  function rectIntersectionArea(rectA, rectB) {
    if (!rectA || !rectB) return 0;
    const left = Math.max(rectA.left, rectB.left);
    const right = Math.min(rectA.right, rectB.right);
    const top = Math.max(rectA.top, rectB.top);
    const bottom = Math.min(rectA.bottom, rectB.bottom);
    if (right <= left || bottom <= top) return 0;
    return (right - left) * (bottom - top);
  }

  function getOverlapRatio(mainRect, candRect) {
    const intersectionArea = rectIntersectionArea(mainRect, candRect);
    const areaMain = getRectArea(mainRect);
    const areaCand = getRectArea(candRect);
    const baseArea = Math.max(1, Math.min(areaMain, areaCand));
    return intersectionArea / baseArea;
  }

  function hasStackingContextHint(el) {
    if (!(el instanceof Element)) return false;

    let current = el.parentElement;
    let depth = 0;
    while (current && depth < STACKING_SCAN_MAX_DEPTH) {
      const style = getComputedStyle(current);
      const opacity = Number.parseFloat(style.opacity || "1");
      const hasWillChangeHint = (style.willChange || "").toLowerCase().split(",").some((v) => {
        const t = v.trim();
        return t === "transform" || t === "opacity" || t === "filter";
      });

      if (
        opacity < 1 ||
        style.transform !== "none" ||
        style.filter !== "none" ||
        style.perspective !== "none" ||
        style.mixBlendMode !== "normal" ||
        style.isolation === "isolate" ||
        style.position === "fixed" ||
        hasWillChangeHint
      ) {
        return true;
      }

      current = current.parentElement;
      depth += 1;
    }
    return false;
  }

  function hasClickableHint(el) {
    if (!(el instanceof Element)) return { matched: false, decorativeOnly: false };
    const style = getComputedStyle(el);
    const cursorPointer = style.cursor === "pointer";
    const clickableNode =
      el.matches("a, button, [role='link'], [onclick]") ||
      Boolean(el.querySelector("a, button, [role='link'], [onclick]"));

    const decorativeOnly = style.pointerEvents === "none" && !cursorPointer && !clickableNode;
    return { matched: cursorPointer || clickableNode, decorativeOnly };
  }

  function getTextLength(el) {
    const text = (el.textContent || "").replace(/\s+/g, " ").trim();
    return text.length;
  }

  function getArticleMarkerCount(el) {
    if (!(el instanceof Element)) return 0;

    let score = 0;
    if (el.matches(ARTICLE_MARKER_SELECTOR)) score += 2;
    if (el.querySelector(ARTICLE_MARKER_SELECTOR)) score += 2;
    if (el.closest(ARTICLE_MARKER_SELECTOR)) score += 2;

    const clsId = `${el.id || ""} ${(el.className || "").toString()}`.toLowerCase();
    if (/(^|[^a-z])(article|entry|post|archive|feed)([^a-z]|$)/.test(clsId)) score += 1;
    if (/(articlebody|entrycontent|postcontent|articlecontent|maincontent)/.test(clsId)) score += 1;
    return score;
  }

  function hasArticleStructure(el) {
    if (!(el instanceof Element)) return false;
    if (el.matches(ARTICLE_STRUCTURE_SELECTOR)) return true;
    return Boolean(el.querySelector(ARTICLE_STRUCTURE_SELECTOR));
  }

  function isProtectedContentTree(el, mainEl = null) {
    if (!(el instanceof Element)) return false;

    const markerScore = getArticleMarkerCount(el);
    if (markerScore >= 3) return true;
    if (markerScore >= 2 && hasArticleStructure(el)) return true;

    const textLength = getTextLength(el);
    const paragraphCount = el.querySelectorAll("p").length;
    const headingCount = el.querySelectorAll("h1, h2, h3, h4").length;
    const timeCount = el.querySelectorAll("time").length;
    const linkCount = el.querySelectorAll("a").length;
    const mediaCount = el.querySelectorAll("img, iframe, ins").length;

    if (headingCount >= 1 && (paragraphCount >= 1 || timeCount >= 1)) return true;
    if (paragraphCount >= 3 && textLength >= 220) return true;
    if (timeCount >= 1 && textLength >= 120) return true;
    if (mainEl instanceof Element && (el === mainEl || el.contains(mainEl) || mainEl.contains(el))) {
      if (textLength >= 180 || paragraphCount >= 2 || headingCount >= 1) return true;
    }
    if (textLength >= 320 && linkCount >= 3 && mediaCount <= linkCount + 2) return true;
    return false;
  }

  function isAdLikeWrapper(el) {
    if (!(el instanceof Element)) return false;
    const textLength = getTextLength(el);
    const clsId = `${el.id || ""} ${(el.className || "").toString()}`.toLowerCase();
    const childCount = el.childElementCount;
    const mediaCount = el.querySelectorAll("img, iframe, ins").length;
    return (
      hasAttributeSignal(el) ||
      /(^|[^a-z])(ad|ads|sponsor|promo|banner)([^a-z]|$)/.test(clsId) ||
      (textLength <= INLINE_TEXT_LIMIT && childCount <= 4 && mediaCount >= 1 && !hasArticleStructure(el))
    );
  }
  function getContentLikelihood(el, mainEl = null) {
    if (!(el instanceof Element)) return { score: 0, reasons: [] };

    let score = 0;
    const reasons = [];
    const textLength = getTextLength(el);
    const paragraphCount = el.querySelectorAll("p").length;
    const headingCount = el.querySelectorAll("h1, h2, h3, h4").length;
    const timeCount = el.querySelectorAll("time").length;
    const listCount = el.querySelectorAll("ul, ol, li").length;
    const linkCount = el.querySelectorAll("a").length;
    const imageCount = el.querySelectorAll("img").length;
    const articleMarkers = getArticleMarkerCount(el);

    if (textLength >= 280) {
      score += 2;
      reasons.push("long-text");
    }
    if (paragraphCount >= 2) {
      score += 2;
      reasons.push("paragraphs");
    }
    if (headingCount >= 1) {
      score += 2;
      reasons.push("headings");
    }
    if (timeCount >= 1) {
      score += 1;
      reasons.push("time");
    }
    if (listCount >= 3) {
      score += 1;
      reasons.push("lists");
    }
    if (articleMarkers >= 1) {
      score += 3;
      reasons.push("article-markers");
    }
    if (mainEl instanceof Element && (el === mainEl || el.contains(mainEl) || mainEl.contains(el))) {
      score += 2;
      reasons.push("main-related");
    }

    if (linkCount >= 6 && textLength >= 220) {
      score += 1;
      reasons.push("link-dense-text");
    }
    if (imageCount >= 3 && textLength >= 180) {
      score += 1;
      reasons.push("media-with-text");
    }

    return { score, reasons };
  }

  function shouldSuppressForContentLikelihood(el, options = {}) {
    const { mainEl = null, maxScore = 3, allowShortText = false } = options;
    if (isProtectedContentTree(el, mainEl)) {
      const content = getContentLikelihood(el, mainEl);
      return { suppress: true, score: Math.max(content.score, maxScore + 1), reasons: [...content.reasons, "protected-content-tree"] };
    }
    const content = getContentLikelihood(el, mainEl);
    if (allowShortText && getTextLength(el) <= INLINE_TEXT_LIMIT) {
      return { suppress: false, score: content.score, reasons: content.reasons };
    }
    return {
      suppress: content.score > maxScore,
      score: content.score,
      reasons: content.reasons
    };
  }

  function hasInlineIframeHint(el) {
    return hasTagSignal(el) || Boolean(el.querySelector("iframe, ins, aside"));
  }

  function isInteractiveChrome(el) {
    return Boolean(el.closest("header, nav, footer, [role='navigation']"));
  }

  function isWithinMainFlow(el, mainEl) {
    if (!(el instanceof Element) || !(mainEl instanceof Element)) return false;
    return el === mainEl || mainEl.contains(el);
  }

  function getDomDepth(el) {
    let depth = 0;
    let current = el;
    while (current && current.parentElement) {
      current = current.parentElement;
      depth += 1;
      if (depth >= 64) break;
    }
    return depth;
  }

  function getClassTokenSet(el) {
    return new Set(
      ((el.className || "").toString().toLowerCase().match(/[a-z0-9_-]{2,}/g) || []).filter(Boolean)
    );
  }

  function getRailSignature(el, rect) {
    return {
      width: Math.round(rect.width),
      height: Math.round(rect.height),
      depth: getDomDepth(el),
      classTokens: getClassTokenSet(el),
      imgCount: el.querySelectorAll("img").length,
      linkCount: el.querySelectorAll("a").length,
      iframeCount: el.querySelectorAll("iframe, ins").length
    };
  }

  function getSideRailSimilarityBonus(signature, signatures) {
    let bestBonus = 0;
    for (const other of signatures) {
      if (other === signature) continue;
      let bonus = 0;
      if (Math.abs(signature.width - other.width) <= 24 && Math.abs(signature.height - other.height) <= 60) {
        bonus += 1;
      }
      if (Math.abs(signature.depth - other.depth) <= 2) {
        bonus += 1;
      }
      const sharedClasses = [...signature.classTokens].filter((token) => other.classTokens.has(token));
      if (sharedClasses.length >= 1) {
        bonus += 1;
      }
      if (
        signature.imgCount === other.imgCount &&
        signature.linkCount === other.linkCount &&
        signature.iframeCount === other.iframeCount &&
        signature.imgCount + signature.linkCount + signature.iframeCount > 0
      ) {
        bonus += 1;
      }
      if (bonus > bestBonus) bestBonus = bonus;
    }
    return Math.min(2, bestBonus);
  }

  function findMainContent() {
    const selectors = ["main", "article", "[role='main']", "#main", ".main", ".content", ".article", ".entry-content", ".post-content"];
    const unique = new Set();
    const candidates = [];
    const viewportArea = getViewportArea();
    const viewportCenterX = window.innerWidth / 2;

    for (const selector of selectors) {
      const found = document.querySelectorAll(selector);
      for (const el of found) {
        if (!(el instanceof Element)) continue;
        if (unique.has(el)) continue;
        unique.add(el);
        if (!isElementVisible(el)) continue;

        const rect = el.getBoundingClientRect();
        const area = getRectArea(rect);
        if (area < viewportArea * 0.06) continue;
        if (rect.width < window.innerWidth * 0.26) continue;
        if (rect.right < viewportCenterX - window.innerWidth * 0.08 || rect.left > viewportCenterX + window.innerWidth * 0.08) continue;

        const textLength = Math.min(getTextLength(el), 6000);
        const centerX = rect.left + rect.width / 2;
        const centerPenalty = Math.abs(centerX - viewportCenterX) / Math.max(1, window.innerWidth);
        const content = getContentLikelihood(el, null);
        const markerScore = getArticleMarkerCount(el);
        const paragraphCount = el.querySelectorAll("p").length;
        const headingCount = el.querySelectorAll("h1, h2, h3").length;
        const score =
          area +
          textLength * 45 +
          content.score * 50000 +
          markerScore * 70000 +
          paragraphCount * 12000 +
          headingCount * 8000 -
          centerPenalty * 220000;
        candidates.push({ el, score });
      }
    }

    candidates.sort((a, b) => b.score - a.score);
    return candidates.length > 0 ? candidates[0].el : null;
  }
  function getRemovableTarget(el, mainEl = null) {
    if (!(el instanceof Element)) return el;
    if (isProtectedContentTree(el, mainEl)) return el;

    if (el.tagName === "IFRAME" || el.tagName === "INS") {
      const p = el.parentElement;
      if (p && p !== document.body && p !== document.documentElement && !isProtectedContentTree(p, mainEl) && isAdLikeWrapper(p)) {
        const rect = p.getBoundingClientRect();
        const area = getRectArea(rect);
        if (area <= getViewportArea() * 0.45 && getTextLength(p) <= INLINE_TEXT_LIMIT) return p;
      }
    }

    if (mainEl instanceof Element) {
      const parent = el.parentElement;
      if (
        parent &&
        parent !== mainEl &&
        !isInteractiveChrome(parent) &&
        !isProtectedContentTree(parent, mainEl) &&
        isAdLikeWrapper(parent) &&
        parent.childElementCount <= 4 &&
        getTextLength(parent) <= INLINE_TEXT_LIMIT &&
        !parent.querySelector(ARTICLE_STRUCTURE_SELECTOR)
      ) {
        const parentRect = parent.getBoundingClientRect();
        const currentRect = el.getBoundingClientRect();
        if (getRectArea(parentRect) <= getRectArea(currentRect) * 1.8) return parent;
      }
    }

    return el;
  }


  function getDockedTarget(el, mainEl = null) {
    if (!(el instanceof Element)) return el;
    let current = el;
    let depth = 0;
    while (current && current !== document.body && current !== document.documentElement && depth < 6) {
      if (isProtectedContentTree(current, mainEl)) break;
      const style = getComputedStyle(current);
      const rect = current.getBoundingClientRect();
      const dock = isDockedEdgePosition(rect);
      if ((style.position === "fixed" || style.position === "sticky") && dock.matched) {
        return current;
      }
      current = current.parentElement;
      depth += 1;
    }
    return getRemovableTarget(el, mainEl);
  }
  function findOverlayCandidates(elements) {
    const viewportArea = getViewportArea();
    const candidates = [];

    for (const el of elements) {
      if (shouldSkipForRemoval(el)) continue;
      if (!isElementVisible(el)) continue;

      const style = getComputedStyle(el);
      if (style.position !== "fixed" && style.position !== "absolute") continue;

      const zIndex = parseNumber(style.zIndex, 0);
      if (zIndex < OVERLAY_MIN_Z_INDEX) continue;

      const rect = el.getBoundingClientRect();
      const area = getRectArea(rect);
      const areaRatio = area / viewportArea;
      if (areaRatio < 0.58) continue;

      let score = 4;
      const role = (el.getAttribute("role") || "").toLowerCase();
      const clsId = `${el.id || ""} ${(el.className || "").toString()}`.toLowerCase();
      const dismissControl = hasDismissControl(el);

      if (el.getAttribute("aria-modal") === "true") score += 3;
      if (role.includes("dialog")) score += 2;
      if (/(overlay|modal|dialog|popup|lightbox|paywall)/i.test(clsId)) score += 2;
      if (areaRatio >= 0.8) score += 2;
      if (zIndex >= 2000) score += 1;
      if (dismissControl) score += 1;

      candidates.push({ el, score });
    }

    candidates.sort((a, b) => b.score - a.score);
    return candidates.slice(0, MAX_OVERLAY_SCAN);
  }

  function hideBackdropLikeElements(elements) {
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    let hidden = 0;

    for (const el of elements) {
      if (shouldSkipForRemoval(el)) continue;
      if (!isElementVisible(el)) continue;

      const style = getComputedStyle(el);
      const position = style.position;
      if (position !== "fixed" && position !== "absolute") continue;

      const z = parseNumber(style.zIndex, 0);
      if (z < OVERLAY_MIN_Z_INDEX) continue;

      const rect = el.getBoundingClientRect();
      if (rect.width < vw * 0.85 || rect.height < vh * 0.85) continue;

      const background = (style.backgroundColor || "").toLowerCase();
      const backdropLike = background.includes("rgba") || background.includes("hsla") || background.includes("rgb(0") || background.includes("rgb(1");
      if (!backdropLike) continue;

      if (recordAndHide(el, "overlay-backdrop")) hidden += 1;
      if (hidden >= 3) break;
    }

    return hidden;
  }

  function removeOverlayAndBackdrop(settings, elements) {
    if (!settings.enableOverlay) return { clicked: 0, hidden: 0 };

    let clicked = 0;
    let hidden = 0;
    const overlays = findOverlayCandidates(elements);

    for (const candidate of overlays) {
      const closeButton = findCloseButton(candidate.el);
      if (closeButton) {
        closeButton.click();
        clicked += 1;
      }
    }

    for (const candidate of overlays) {
      if (recordAndHide(candidate.el, "overlay-main")) hidden += 1;
    }

    hidden += hideBackdropLikeElements(elements);
    return { clicked, hidden };
  }

  function removeInlineAds(settings, vocabSet, hostHints, elements, mainEl) {
    if (!(mainEl instanceof Element)) return 0;

    const viewportArea = getViewportArea();
    const threshold = settings.scoreThreshold;
    const maxRemovals = Math.min(MAX_INLINE_REMOVE, settings.maxNormalRemovals);
    const mainRect = mainEl.getBoundingClientRect();
    const candidates = [];

    for (const el of elements) {
      if (shouldSkipForRemoval(el)) continue;
      if (!isElementVisible(el)) continue;
      if (el.hasAttribute(HIDDEN_ATTR)) continue;
      if (!isWithinMainFlow(el, mainEl)) continue;
      if (isInteractiveChrome(el)) continue;
      if (isNearVideoOrCanvas(el) && !isAdVideoContainer(el)) continue;

      const style = getComputedStyle(el);
      if (style.position === "fixed") continue;

      if (isProtectedContentTree(el, mainEl)) continue;
      const contentGuard = shouldSuppressForContentLikelihood(el, { mainEl, maxScore: 3, allowShortText: true });
      if (contentGuard.suppress) continue;

      const rect = el.getBoundingClientRect();
      const area = getRectArea(rect);
      if (area <= 0 || area >= viewportArea * 0.45) continue;
      if (rect.width < mainRect.width * 0.28) continue;
      if (rect.top < mainRect.top - 32 || rect.bottom > mainRect.bottom + 32) continue;

      let score = 0;
      let reasons = 0;
      let articleBreak = false;
      const textLength = getTextLength(el);

      if (hasInlineIframeHint(el)) {
        score += 2;
        reasons += 1;
      }
      if (settings.signalSize && hasSizeSignal(el, rect)) {
        score += 2;
        reasons += 1;
      }
      if (settings.signalTag && hasTagSignal(el)) {
        score += 1;
        reasons += 1;
      }
      if (settings.signalPosition && hasPositionSignal(el, rect)) {
        score += 1;
        reasons += 1;
      }
      if (hasDirectAdSignature(el)) {
        score += 3;
        reasons += 1;
      }
      if (hasAdHostSignal(el, hostHints)) {
        score += 4;
        reasons += 1;
      }
      if (settings.signalVocab && hasVocabSignal(el, vocabSet)) {
        score += 2;
        reasons += 1;
      }
      if (settings.signalAttribute && hasAttributeSignal(el)) {
        score += 1;
        reasons += 1;
      }
      if (textLength <= INLINE_TEXT_LIMIT) {
        score += 1;
        articleBreak = true;
      }

      const overlapsMainCenter = rect.left <= mainRect.left + mainRect.width * 0.7 && rect.right >= mainRect.left + mainRect.width * 0.3;
      if (overlapsMainCenter) {
        score += 1;
        articleBreak = true;
      }

      if (score >= threshold && reasons >= 2 && articleBreak) {
        candidates.push({ el, score, reasons, area });
      }
    }

    candidates.sort((a, b) => {
      if (b.score !== a.score) return b.score - a.score;
      if (a.area !== b.area) return a.area - b.area;
      return b.reasons - a.reasons;
    });

    let removed = 0;
    const removedTargets = [];
    for (const candidate of candidates) {
      if (removed >= maxRemovals) break;
      const target = getRemovableTarget(candidate.el, mainEl);
      if (!(target instanceof Element)) continue;
      const overlapsExisting = removedTargets.some((done) => done === target || done.contains(target) || target.contains(done));
      if (overlapsExisting) continue;
      if (recordAndHide(target, "inline-article-ad")) {
        removed += 1;
        removedTargets.push(target);
      }
    }

    return removed;
  }


  function removeSideRailAds(settings, vocabSet, hostHints, elements, mainEl) {
    if (!(mainEl instanceof Element)) return 0;

    const mainRect = mainEl.getBoundingClientRect();
    const viewportArea = getViewportArea();
    const vh = window.innerHeight;
    const articleCardWidthThreshold = mainRect.width * 0.72;
    const candidates = [];

    for (const el of elements) {
      if (shouldSkipForRemoval(el)) continue;
      if (!isElementVisible(el)) continue;
      if (el.hasAttribute(HIDDEN_ATTR)) continue;
      if (isWithinMainFlow(el, mainEl)) continue;
      if (isInteractiveChrome(el)) continue;
      if (isNearVideoOrCanvas(el) && !isAdVideoContainer(el)) continue;

      const style = getComputedStyle(el);
      const positionOk = ["fixed", "sticky", "absolute"].includes(style.position) || style.position === "static" || style.position === "relative";
      if (!positionOk) continue;

      if (isProtectedContentTree(el, mainEl)) continue;
      const contentGuard = shouldSuppressForContentLikelihood(el, { mainEl, maxScore: 2, allowShortText: true });
      if (contentGuard.suppress) continue;
      if (el.querySelector(ARTICLE_STRUCTURE_SELECTOR)) continue;
      if (el.closest("article, .entry-content, .post-content, .article-body")) continue;

      const rect = el.getBoundingClientRect();
      const area = getRectArea(rect);
      if (area <= 0 || area >= viewportArea * 0.3) continue;
      if (rect.width < 100 || rect.width > 520) continue;
      if (rect.width >= articleCardWidthThreshold) continue;
      if (rect.height < 180 || rect.height > vh * 0.95) continue;
      if (getTextLength(el) > INLINE_TEXT_LIMIT) continue;
      if (!isSideRailPosition(rect, mainRect)) continue;

      let score = 1;
      let reasons = 0;
      const textLength = getTextLength(el);
      const imgCount = el.querySelectorAll("img").length;
      const linkCount = el.querySelectorAll("a").length;
      const iframeCount = el.querySelectorAll("iframe, ins").length;
      const childCount = Math.max(1, el.childElementCount);
      const mediaCount = imgCount + iframeCount;
      const mediaDominant = mediaCount >= 1 && (linkCount >= 1 || mediaCount >= childCount * 0.5);
      const stackedImages = imgCount >= 2 && rect.height >= rect.width * 1.4;
      const narrowRail = rect.width <= Math.min(420, mainRect.width * 0.42);
      const imageHeavy = mediaCount >= 1 && textLength <= 72;
      const closeButton = findCloseButton(el);
      const collapseControl = findCollapseControl(el);
      const dismissTarget = closeButton?.closest("[style], [class], [id]") || collapseControl?.closest("[style], [class], [id]") || el;
      const hasDismissUi = Boolean(closeButton || collapseControl);
      const bundleInfo = getAbsoluteAdLinkBundleInfo(el, hostHints);

      if (settings.signalTag && (hasTagSignal(el) || Boolean(el.querySelector("iframe, ins, aside, img")))) {
        score += 2;
        reasons += 1;
      }
      if (hasDirectAdSignature(el)) {
        score += 3;
        reasons += 1;
      }
      if (hasAdHostSignal(el, hostHints)) {
        score += 4;
        reasons += 1;
      }
      if (settings.signalVocab && hasVocabSignal(el, vocabSet)) {
        score += 2;
        reasons += 1;
      }
      if (settings.signalAttribute && hasAttributeSignal(el)) {
        score += 1;
        reasons += 1;
      }
      if (settings.signalSize && hasSizeSignal(el, rect)) {
        score += 1;
        reasons += 1;
      }
      if (mediaDominant) {
        score += 2;
      }
      if (stackedImages) {
        score += 1;
      }
      if (settings.enableEdgeClickableHint && hasClickableHint(el).matched) {
        score += 1;
      }
      if (hasDismissUi) {
        score += 2;
        reasons += 1;
      }
      if (bundleInfo.matched) {
        score += bundleInfo.score;
        reasons += 1;
      }
      if (textLength <= INLINE_TEXT_LIMIT) {
        score += 1;
      }
      if (narrowRail) {
        score += 1;
      }
      if (imageHeavy) {
        score += 1;
      }

      if (reasons < 1 && !mediaDominant) continue;
      if (!mediaDominant && !imageHeavy && !hasDismissUi && !bundleInfo.matched) continue;
      if ((mediaDominant && narrowRail && textLength <= INLINE_TEXT_LIMIT) || stackedImages) score += 1;
      if (hasDismissUi && hasDirectAdSignature(el)) score += 2;
      candidates.push({ el, score, area, signature: getRailSignature(el, rect), closeButton, collapseControl, dismissTarget, preferredTarget: bundleInfo.container, hasDismissUi });
    }

    const signatures = candidates.map((candidate) => candidate.signature);
    for (const candidate of candidates) {
      candidate.score += getSideRailSimilarityBonus(candidate.signature, signatures);
    }

    candidates.sort((a, b) => {
      if (b.score !== a.score) return b.score - a.score;
      return b.area - a.area;
    });

    let removed = 0;
    const removedTargets = [];
    for (const candidate of candidates) {
      if (removed >= MAX_SIDE_RAIL_REMOVE) break;
      if (candidate.hasDismissUi) {
        if (candidate.collapseControl) candidate.collapseControl.click();
        else if (candidate.closeButton) candidate.closeButton.click();
      }
      if (candidate.score < (candidate.hasDismissUi ? Math.max(3, settings.scoreThreshold - 1) : Math.max(3, settings.scoreThreshold - 1))) continue;
      const target = getDockedTarget(candidate.preferredTarget || candidate.dismissTarget || candidate.el, mainEl);
      if (!(target instanceof Element)) continue;
      const overlapsExisting = removedTargets.some((done) => done === target || done.contains(target) || target.contains(done));
      if (overlapsExisting) continue;
      if (recordAndHide(target, "side-rail-ad")) {
        removed += 1;
        removedTargets.push(target);
      }
    }

    return removed;
  }

  function removeStructuralEdgeAds(settings, vocabSet, hostHints, elements, mainEl) {
    if (!settings.enableStructEdgeAds) return 0;
    if (!(mainEl instanceof Element)) return 0;

    const mainRect = mainEl.getBoundingClientRect();
    const mainZ = parseZIndex(getComputedStyle(mainEl).zIndex) ?? 0;
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const threshold = settings.edgeStructThreshold;
    const maxRemove = settings.edgeStructMaxRemove;
    const candidates = [];

    for (const el of elements) {
      if (shouldSkipForRemoval(el)) continue;
      if (!isElementVisible(el)) continue;
      if (el.hasAttribute(HIDDEN_ATTR)) continue;
      if (isNearVideoOrCanvas(el) && !isAdVideoContainer(el)) continue;

      const style = getComputedStyle(el);
      if (style.position !== "fixed") continue;

      if (isProtectedContentTree(el, mainEl)) continue;
      const contentGuard = shouldSuppressForContentLikelihood(el, { mainEl, maxScore: 2, allowShortText: true });
      if (contentGuard.suppress) continue;

      const rect = el.getBoundingClientRect();
      const wideEnough = rect.width >= vw * 0.8;
      const shortEnough = rect.height <= vh * settings.edgeMaxHeightRatio;
      const notTooThin = rect.height >= EDGE_MIN_HEIGHT_PX;
      const nearTop = rect.top <= EDGE_MARGIN;
      const nearBottom = rect.bottom >= vh - EDGE_MARGIN;
      if (!wideEnough || !shortEnough || !notTooThin || (!nearTop && !nearBottom)) continue;

      const candZ = parseZIndex(style.zIndex);
      const zHigh = candZ !== null && candZ >= EDGE_MIN_Z_INDEX;
      const weakCandidate = candZ === null || candZ === 0;
      if (!zHigh && !weakCandidate) continue;

      let score = 2;
      let overlapMatched = false;
      let vocabMatched = false;
      const dismissControl = hasDismissControl(el);
      const stackingGuardActive =
        settings.enableEdgeStackingGuard &&
        (hasStackingContextHint(mainEl) || hasStackingContextHint(el));

      if (!stackingGuardActive && candZ !== null && candZ > mainZ) {
        score += 2;
      }

      if (settings.enableEdgeOverlap) {
        const overlapRatio = getOverlapRatio(mainRect, rect);
        if (overlapRatio >= settings.edgeOverlapThreshold) {
          score += 2;
          overlapMatched = true;
        }
      }

      if (settings.enableEdgeClickableHint) {
        const clickableHint = hasClickableHint(el);
        if (clickableHint.matched) {
          score += 1;
        } else if (clickableHint.decorativeOnly) {
          score -= 1;
        }
      }
      if (dismissControl) {
        score += 2;
      }

      if (hasDirectAdSignature(el)) {
        score += 3;
        vocabMatched = true;
      }
      if (hasAdHostSignal(el, hostHints)) {
        score += 4;
        vocabMatched = true;
      }
      if (settings.enableEdgeVocabHint && hasVocabSignal(el, vocabSet)) {
        score += 2;
        vocabMatched = true;
      }

      if (settings.enableEdgeAttributeHint && hasAttributeSignal(el)) {
        score += 1;
      }

      if (stackingGuardActive && !overlapMatched && !vocabMatched) continue;
      if (score >= threshold) {
        candidates.push({ el, score, overlapMatched, vocabMatched });
      }
    }

    candidates.sort((a, b) => {
      if (b.score !== a.score) return b.score - a.score;
      if (b.overlapMatched !== a.overlapMatched) return b.overlapMatched ? -1 : 1;
      if (b.vocabMatched !== a.vocabMatched) return b.vocabMatched ? -1 : 1;
      return 0;
    });

    let removed = 0;
    const removedTargets = [];
    for (const candidate of candidates) {
      if (removed >= maxRemove) break;
      const target = getRemovableTarget(candidate.el, mainEl);
      if (!(target instanceof Element)) continue;
      const overlapsExisting = removedTargets.some((done) => done === target || done.contains(target) || target.contains(done));
      if (overlapsExisting) continue;
      const closeButton = findCloseButton(target);
      if (closeButton) closeButton.click();
      if (recordAndHide(target, "edge-structural-ad")) {
        removed += 1;
        removedTargets.push(target);
      }
    }

    return removed;
  }

  function removeDockedEdgeAds(settings, vocabSet, hostHints, elements, mainEl) {
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const viewportArea = getViewportArea();
    const mainRect = mainEl instanceof Element ? mainEl.getBoundingClientRect() : null;
    const candidates = [];

    for (const el of elements) {
      if (shouldSkipForRemoval(el)) continue;
      if (!isElementVisible(el)) continue;
      if (el.hasAttribute(HIDDEN_ATTR)) continue;
      if (isNearVideoOrCanvas(el) && !isAdVideoContainer(el)) continue;
      if (isProtectedContentTree(el, mainEl)) continue;

      const style = getComputedStyle(el);
      if (style.position !== "fixed" && style.position !== "sticky") continue;

      const rect = el.getBoundingClientRect();
      const area = getRectArea(rect);
      if (area < viewportArea * 0.01 || area > viewportArea * 0.35) continue;

      const dock = isDockedEdgePosition(rect);
      if (!dock.matched) continue;

      const contentGuard = shouldSuppressForContentLikelihood(el, { mainEl, maxScore: 2, allowShortText: true });
      if (contentGuard.suppress) continue;

      const closeButton = findCloseButton(el);
      const collapseControl = findCollapseControl(el);
      const dismissTarget = closeButton?.closest("[style], [class], [id]") || collapseControl?.closest("[style], [class], [id]") || el;
      const adVideoContainer = isAdVideoContainer(el);
      const bundleInfo = getAbsoluteAdLinkBundleInfo(el, hostHints);
      const clickableHint = hasClickableHint(el);
      const hasMedia = Boolean(el.querySelector("iframe, ins, aside, img, video"));
      const hasVideo = Boolean(el.querySelector("video"));
      const z = parseNumber(style.zIndex, 0);
      const transformActive = style.transform && style.transform !== "none";
      const overlapRatio = mainRect ? getOverlapRatio(mainRect, rect) : 0;
      const shortText = getTextLength(el) <= Math.max(INLINE_TEXT_LIMIT, 220);

      let score = 1;
      let signals = 0;
      const hasDismissUi = Boolean(closeButton || collapseControl);
      if (dock.bottomTopBand || dock.sideBand) score += 1;
      if (dock.cornerFloat) score += 2;
      if (closeButton) {
        score += 3;
        signals += 1;
      }
      if (collapseControl) {
        score += 3;
        signals += 1;
      }
      if (hasDirectAdSignature(el)) {
        score += 3;
        signals += 1;
      }
      if (hasAdHostSignal(el, hostHints)) {
        score += 4;
        signals += 1;
      }
      if (settings.enableEdgeVocabHint && hasVocabSignal(el, vocabSet)) {
        score += 2;
        signals += 1;
      }
      if (settings.enableEdgeAttributeHint && hasAttributeSignal(el)) {
        score += 1;
        signals += 1;
      }
      if (clickableHint.matched) {
        score += 1;
        signals += 1;
      }
      if (hasMedia) {
        score += 1;
        signals += 1;
      }
      if (bundleInfo.matched) {
        score += bundleInfo.score;
        signals += 1;
      }
      if (hasVideo && (hasDirectAdSignature(el) || hasDismissUi || z >= 999 || adVideoContainer)) {
        score += 3;
        signals += 1;
      }
      if (transformActive) score += 1;
      if (shortText) score += 1;
      if (z >= EDGE_MIN_Z_INDEX) score += 1;
      if (overlapRatio >= 0.08) score += 1;
      if (rect.width >= vw * 0.4 && rect.height <= vh * 0.28) score += 1;
      if (rect.height >= vh * 0.35 && rect.width <= vw * 0.3) score += 1;
      if (dock.nearBottom && rect.height <= vh * 0.3) score += 1;

      if (!hasDismissUi && !dock.cornerFloat && signals < 2) continue;
      if (hasDismissUi && score >= 4) {
        candidates.push({ el, score, closeButton, collapseControl, dismissTarget, area });
        continue;
      }
      if (adVideoContainer && score >= 4) {
        candidates.push({ el, score, closeButton, collapseControl, dismissTarget, area });
        continue;
      }
      if (dock.cornerFloat && hasMedia && clickableHint.matched && score >= 4) {
        candidates.push({ el, score, closeButton, collapseControl, dismissTarget, preferredTarget: bundleInfo.container, area });
        continue;
      }
      if (bundleInfo.matched && score >= 4) {
        candidates.push({ el, score, closeButton, collapseControl, dismissTarget, preferredTarget: bundleInfo.container, area });
        continue;
      }
      if (score >= 5) {
        candidates.push({ el, score, closeButton, collapseControl, dismissTarget, preferredTarget: bundleInfo.container, area });
      }
    }

    candidates.sort((a, b) => {
      if (b.score !== a.score) return b.score - a.score;
      return b.area - a.area;
    });

    let removed = 0;
    const removedTargets = [];
    for (const candidate of candidates) {
      if (removed >= 3) break;
      if (candidate.collapseControl) candidate.collapseControl.click();
      else if (candidate.closeButton) candidate.closeButton.click();

      const target = getDockedTarget(candidate.preferredTarget || candidate.dismissTarget || candidate.el, mainEl);
      if (!(target instanceof Element)) continue;
      const overlapsExisting = removedTargets.some((done) => done === target || done.contains(target) || target.contains(done));
      if (overlapsExisting) continue;
      if (recordAndHide(target, "edge-docked-ad")) {
        removed += 1;
        removedTargets.push(target);
      }
    }

    return removed;
  }

  function removeEdgeBanners(settings, vocabSet, hostHints, elements, mainEl) {
    if (!settings.enableEdgeBanner) return 0;

    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const mainRect = mainEl instanceof Element ? mainEl.getBoundingClientRect() : null;
    const candidates = [];

    for (const el of elements) {
      if (shouldSkipForRemoval(el)) continue;
      if (!isElementVisible(el)) continue;
      if (el.hasAttribute(HIDDEN_ATTR)) continue;

      const style = getComputedStyle(el);
      if (style.position !== "fixed") continue;

      const z = parseNumber(style.zIndex, 0);
      if (z < EDGE_MIN_Z_INDEX) continue;

      const rect = el.getBoundingClientRect();
      const wideEnough = rect.width >= vw * 0.78;
      const shortEnough = rect.height <= vh * settings.edgeMaxHeightRatio;
      const notTooThin = rect.height >= EDGE_MIN_HEIGHT_PX;
      const nearTop = rect.top <= EDGE_MARGIN;
      const nearBottom = rect.bottom >= vh - EDGE_MARGIN;
      if (!wideEnough || !shortEnough || !notTooThin || (!nearTop && !nearBottom)) continue;

      let score = 2;
      let adSignals = 0;
      const dismissControl = hasDismissControl(el);

      if (dismissControl) {
        score += 2;
        adSignals += 1;
      }
      if (hasDirectAdSignature(el)) {
        score += 3;
        adSignals += 1;
      }
      if (hasAdHostSignal(el, hostHints)) {
        score += 4;
        adSignals += 1;
      }
      if (settings.enableEdgeVocabHint && hasVocabSignal(el, vocabSet)) {
        score += 2;
        adSignals += 1;
      }
      if (settings.enableEdgeAttributeHint && hasAttributeSignal(el)) {
        score += 1;
        adSignals += 1;
      }
      if (settings.enableEdgeClickableHint && hasClickableHint(el).matched) {
        score += 1;
        adSignals += 1;
      }
      if (mainRect && getOverlapRatio(mainRect, rect) >= settings.edgeOverlapThreshold) {
        score += 1;
      }
      if (getTextLength(el) <= INLINE_TEXT_LIMIT) {
        score += 1;
      }

      if (adSignals < 1) continue;
      if (score >= Math.max(4, settings.edgeStructThreshold - 1)) {
        candidates.push({ el, score });
      }
    }

    candidates.sort((a, b) => b.score - a.score);

    let removed = 0;
    for (const candidate of candidates) {
      const closeButton = findCloseButton(candidate.el);
      if (closeButton) closeButton.click();
      if (recordAndHide(candidate.el, "edge-banner-ad")) {
        removed += 1;
      }
      if (removed >= 2) break;
    }

    return removed;
  }

  async function loadPackagedVocab() {
    if (cachedPackagedVocab) return cachedPackagedVocab;

    try {
      const url = chrome.runtime.getURL("vocab/ad_hint_words.json");
      const res = await fetch(url);
      const json = await res.json();
      cachedPackagedVocab = Array.isArray(json?.words) ? json.words : [];
      return cachedPackagedVocab;
    } catch (_error) {
      cachedPackagedVocab = [];
      return cachedPackagedVocab;
    }
  }

  async function loadRuntimeConfig() {
    const fallback = {
      ...DEFAULT_SETTINGS,
      customHintWords: null,
      customHintMeta: null
    };

    let data = fallback;
    try {
      const storage = await chrome.storage.local.get(fallback);
      data = { ...fallback, ...storage };
    } catch (_error) {
      data = fallback;
    }

    const packaged = await loadPackagedVocab();
    const userWords = Array.isArray(data.customHintWords) ? data.customHintWords : [];
    const userHostHints = userWords.map((w) => normalizeHostHint(w)).filter((w) => isHostLikeHint(w));
    const vocabWords = userWords.filter((w) => !isHostLikeHint(w));
    const vocab = new Set([...CORE_VOCAB, ...packaged, ...vocabWords].map((w) => (w || "").toLowerCase()).filter(Boolean));
    const hostHints = new Set([...CORE_HOST_HINTS, ...userHostHints].map((w) => normalizeHostHint(w)).filter(Boolean));

    return {
      settings: {
        ...DEFAULT_SETTINGS,
        ...data,
        scoreThreshold: Math.max(2, Math.min(12, parseNumber(data.scoreThreshold, DEFAULT_SETTINGS.scoreThreshold))),
        maxNormalRemovals: Math.max(1, Math.min(30, parseNumber(data.maxNormalRemovals, DEFAULT_SETTINGS.maxNormalRemovals))),
        edgeOverlapThreshold: Math.max(0, Math.min(1, parseNumber(data.edgeOverlapThreshold, DEFAULT_SETTINGS.edgeOverlapThreshold))),
        edgeStructThreshold: Math.max(3, Math.min(12, parseNumber(data.edgeStructThreshold, DEFAULT_SETTINGS.edgeStructThreshold))),
        edgeStructMaxRemove: Math.max(1, Math.min(6, parseNumber(data.edgeStructMaxRemove, DEFAULT_SETTINGS.edgeStructMaxRemove))),
        edgeMaxHeightRatio: Math.max(0.1, Math.min(0.6, parseNumber(data.edgeMaxHeightRatio, DEFAULT_SETTINGS.edgeMaxHeightRatio)))
      },
      vocab,
      hostHints
    };
  }

  async function dismissOnce() {
    const { settings, vocab, hostHints } = await loadRuntimeConfig();
    const elements = collectAllElements();
    const mainEl = findMainContent();

    beginBatch("dismiss-once");
    const overlayResult = removeOverlayAndBackdrop(settings, elements);
    clearScrollLock();
    const inlineRemoved = removeInlineAds(settings, vocab, hostHints, elements, mainEl);
    const sideRailRemoved = removeSideRailAds(settings, vocab, hostHints, elements, mainEl);
    const structEdgeRemoved = removeStructuralEdgeAds(settings, vocab, hostHints, elements, mainEl);
    const dockedEdgeRemoved = removeDockedEdgeAds(settings, vocab, hostHints, elements, mainEl);
    const edgeRemoved = removeEdgeBanners(settings, vocab, hostHints, elements, mainEl);
    const changed = finalizeBatch();

    log(settings.debugLogs, {
      overlayClicked: overlayResult.clicked,
      overlayHidden: overlayResult.hidden,
      inlineRemoved,
      sideRailRemoved,
      structEdgeRemoved,
      dockedEdgeRemoved,
      edgeRemoved,
      batchCount: actionHistory.length
    });

    return {
      ok: changed || overlayResult.clicked > 0,
      detail: {
        overlayClicked: overlayResult.clicked,
        overlayHidden: overlayResult.hidden,
        inlineRemoved,
        sideRailRemoved,
        structEdgeRemoved,
        dockedEdgeRemoved,
        edgeRemoved
      }
    };
  }

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (!msg || typeof msg.type !== "string") return undefined;

    if (msg.type === "OK_DISMISS") {
      dismissOnce()
        .then((result) => sendResponse(result))
        .catch((_error) => sendResponse({ ok: false, detail: "dismiss-error" }));
      return true;
    }

    if (msg.type === "OK_UNDO") {
      sendResponse(undoLast());
      return false;
    }

    return undefined;
  });

  setupShadowTracking();
})();







