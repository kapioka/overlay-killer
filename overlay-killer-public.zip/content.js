(() => {
  "use strict";

  const DEFAULT_SETTINGS = {
    signalSize: true,
    signalTag: true,
    signalPosition: false,
    signalVocab: true,
    signalAttribute: true,
    scoreThreshold: 4,
    maxNormalRemovals: 6,
    enableEdgeBanner: true,
    enableStructEdgeAds: true,
    enableEdgeOverlap: true,
    edgeOverlapThreshold: 0.15,
    enableEdgeClickableHint: true,
    enableEdgeStackingGuard: true,
    enableEdgeVocabHint: true,
    enableEdgeAttributeHint: true,
    edgeStructThreshold: 5,
    edgeStructMaxRemove: 2,
    edgeMaxHeightRatio: 0.35,
    enableOverlay: true,
    defaultRunMode: "standard",
    previewProtectOutlines: true,
    learnFromUndo: true,
    debugLogs: false
  };

  const CORE_VOCAB = [
    "ad",
    "ads",
    "advert",
    "advertisement",
    "advertising",
    "adframe",
    "adslot",
    "adservice",
    "adsense",
    "adsbygoogle",
    "sponsor",
    "sponsored",
    "promo",
    "promoted",
    "doubleclick",
    "taboola",
    "outbrain"
  ];
  const CORE_HOST_HINTS = [
    "adclick.g.doubleclick.net",
    "googleads.g.doubleclick.net",
    "doubleclick.net",
    "googlesyndication.com",
    "pagead2.googlesyndication.com",
    "tpc.googlesyndication.com",
    "securepubads.g.doubleclick.net",
    "cdn.adpushup.com",
    "adpushup.com"
  ];

  const OVERLAY_MIN_Z_INDEX = 900;
  const EDGE_MIN_Z_INDEX = 500;
  const EDGE_MARGIN = 8;
  const EDGE_MIN_HEIGHT_PX = 40;
  const STACKING_SCAN_MAX_DEPTH = 12;
  const MAX_OVERLAY_SCAN = 12;
  const INLINE_TEXT_LIMIT = 160;
  const MAX_INLINE_REMOVE = 6;
  const MAX_SIDE_RAIL_REMOVE = 4;
  const ARTICLE_MARKER_SELECTOR = "article, [itemprop='articleBody'], .entry-content, .post-content, .article-body, .entry, .post, .post-body, .post-main, .post-inner, .article-content, .article-main, .entry-main, .single-post, .archive-list";
  const ARTICLE_STRUCTURE_SELECTOR = "article, h1, h2, h3, h4, p, time, ul, ol, li, blockquote";

  const HIDDEN_ATTR = "data-ok-hidden";
  const NEUTRALIZED_ATTR = "data-ok-neutralized";
  const PREVIEW_ATTR = "data-ok-preview";
  const OWNED_ATTR = "data-ok-owned";
  const SHADOW_PATCH_ATTR = "__okAttachShadowPatched";
  const shadowRoots = new Set();
  const actionHistory = [];
  const previewArtifacts = [];
  let cachedPackagedVocab = null;
  let shadowTrackingReady = false;
  let activeBatch = null;
  let commandBusy = false;

  function log(enabled, ...args) {
    if (!enabled) return;
    console.log("[OverlayKiller]", ...args);
  }

  function parseNumber(value, fallback) {
    const n = Number(value);
    return Number.isFinite(n) ? n : fallback;
  }

  function parseZIndex(value) {
    if (value === undefined || value === null) return null;
    const s = String(value).trim().toLowerCase();
    if (!s || s === "auto") return null;
    const n = Number.parseInt(s, 10);
    return Number.isFinite(n) ? n : null;
  }

  function getRectArea(rect) {
    return Math.max(0, rect.width) * Math.max(0, rect.height);
  }

  function getViewportArea() {
    return Math.max(1, window.innerWidth * window.innerHeight);
  }

  function isElementVisible(el) {
    if (!isCandidateEligible(el)) return false;
    const style = getComputedStyle(el);
    if (style.display === "none" || style.visibility === "hidden") return false;
    if (Number.parseFloat(style.opacity || "1") < 0.03) return false;
    const rect = el.getBoundingClientRect();
    if (rect.width < 4 || rect.height < 4) return false;
    return true;
  }

  function shouldSkipForRemoval(el) {
    if (!isCandidateEligible(el)) return true;
    const tag = el.tagName;
    return tag === "VIDEO" || tag === "CANVAS" || tag === "SCRIPT" || tag === "STYLE";
  }

  function isNearVideoOrCanvas(el) {
    if (!(el instanceof Element)) return false;
    if (el.querySelector("video, canvas")) return true;

    let node = el.parentElement;
    let depth = 0;
    while (node && depth < 2) {
      if (node.querySelector("video, canvas")) return true;
      node = node.parentElement;
      depth += 1;
    }
    return false;
  }

  function isAdVideoContainer(el) {
    if (!(el instanceof Element)) return false;
    const hasVideo = Boolean(el.querySelector("video, iframe"));
    if (!hasVideo) return false;

    const clsId = `${el.id || ""} ${(el.className || "").toString()}`.toLowerCase();
    const style = getComputedStyle(el);
    return (
      hasDirectAdSignature(el) ||
      hasAttributeSignal(el) ||
      hasDismissControl(el) ||
      /ima-ad-container|videowrapperdiv|apclosebutton|ap-player|adswift|side-rail-dismiss-btn/.test(clsId) ||
      ((style.position === "fixed" || style.position === "sticky") && parseNumber(style.zIndex, 0) >= 999)
    );
  }

  function beginBatch(label) {
    clearPreviewArtifacts();
    activeBatch = {
      label,
      hidden: [],
      neutralized: [],
      scrollLocks: [],
      scrollRestore: null,
      previewed: [],
      skipped: [],
      settings: null
    };
  }

  function finalizeBatch() {
    if (!activeBatch) return false;
    const hasActions = activeBatch.hidden.length > 0 || activeBatch.neutralized.length > 0 || activeBatch.scrollLocks.length > 0 || activeBatch.previewed.length > 0;
    if (hasActions) {
      if (activeBatch.hidden.length > 0 || activeBatch.neutralized.length > 0 || activeBatch.scrollLocks.length > 0) {
        actionHistory.push(activeBatch);
        if (actionHistory.length > 20) actionHistory.shift();
      }
    }
    activeBatch = null;
    return hasActions;
  }

  function recordScrollState(el, prop) {
    if (!(el instanceof Element) || !activeBatch) return;
    const already = activeBatch.scrollLocks.some((item) => item.el === el && item.prop === prop);
    if (already) return;
    activeBatch.scrollLocks.push({
      el,
      prop,
      value: el.style.getPropertyValue(prop),
      priority: el.style.getPropertyPriority(prop)
    });
  }

  function getCurrentHost() {
    return window.location.hostname || "";
  }

  function normalizeRunMode(mode) {
    if (mode === "strong" || mode === "preview") return mode;
    return "standard";
  }

  function isOverlayReason(reason) {
    return /overlay|backdrop|scroll-lock/.test(String(reason || ""));
  }

  function getSelectorHint(el) {
    if (!(el instanceof Element)) return "";
    const tag = (el.tagName || "").toLowerCase();
    const id = el.id ? `#${CSS.escape(el.id)}` : "";
    const classes = Array.from(el.classList || [])
      .filter((name) => /^[a-z0-9_-]{2,}$/i.test(name))
      .slice(0, 3)
      .map((name) => `.${CSS.escape(name)}`)
      .join("");
    return `${tag}${id}${classes}`.slice(0, 180);
  }

  function getTextSignature(el) {
    const text = (el?.textContent || "").replace(/\s+/g, " ").trim().toLowerCase();
    return text.slice(0, 80);
  }

  function getSavedSiteRules(settings) {
    const host = getCurrentHost();
    const allRules = settings?.siteRules && typeof settings.siteRules === "object" ? settings.siteRules : {};
    return allRules[host] || {};
  }

  function matchesLearnedHint(el, hint) {
    if (!(el instanceof Element) || !hint) return false;
    const selectorHint = typeof hint.selectorHint === "string" ? hint.selectorHint : "";
    if (selectorHint) {
      try {
        if (el.matches(selectorHint) || Boolean(el.closest(selectorHint))) return true;
      } catch (_error) {
        // Ignore stale or invalid learned selectors.
      }
    }

    const classTokens = Array.isArray(hint.classTokens) ? hint.classTokens : [];
    if (classTokens.length > 0) {
      const own = getClassTokenSet(el);
      const shared = classTokens.filter((token) => own.has(token));
      if (shared.length >= Math.min(2, classTokens.length)) return true;
    }

    const textSignature = typeof hint.textSignature === "string" ? hint.textSignature : "";
    if (textSignature && textSignature.length >= 24 && getTextSignature(el).includes(textSignature.slice(0, 32))) {
      return true;
    }
    return false;
  }

  function getProtectionProfile(el, reason, settings) {
    const mainEl = findMainContent();
    const content = getContentLikelihood(el, mainEl);
    const rect = el.getBoundingClientRect();
    const viewportRatio = getRectArea(rect) / getViewportArea();
    const rules = getSavedSiteRules(settings);
    const protectedHints = Array.isArray(rules.protectedHints) ? rules.protectedHints : [];
    const removeHints = Array.isArray(rules.removeHints) ? rules.removeHints : [];

    let protectScore = content.score;
    let riskScore = 0;
    const protectReasons = [...content.reasons];
    const riskReasons = [];

    if (isProtectedContentTree(el, mainEl)) {
      protectScore += 4;
      protectReasons.push("protected-content-tree");
    }
    if (el.matches("main, article, [role='main'], form, nav, header, footer") || el.querySelector("form, input, textarea, select")) {
      protectScore += 3;
      protectReasons.push("major-ui-or-form");
    }
    if (document.activeElement instanceof Element && (el === document.activeElement || el.contains(document.activeElement))) {
      protectScore += 5;
      riskScore += 3;
      protectReasons.push("active-user-focus");
    }
    if (isNearVideoOrCanvas(el) && !isAdVideoContainer(el)) {
      protectScore += 3;
      riskScore += 2;
      protectReasons.push("normal-video-or-canvas");
    }
    if (viewportRatio > 0.55 && !isOverlayReason(reason)) {
      riskScore += 3;
      riskReasons.push("large-page-area");
    }
    if (protectedHints.some((hint) => matchesLearnedHint(el, hint))) {
      protectScore += 5;
      protectReasons.push("learned-protection");
    }
    if (removeHints.some((hint) => matchesLearnedHint(el, hint))) {
      protectScore = Math.max(0, protectScore - 3);
      protectReasons.push("learned-removal");
    }

    return { protectScore, riskScore, protectReasons, riskReasons };
  }

  function classifyRemovalDecision(el, reason, settings) {
    const mode = normalizeRunMode(settings?.currentRunMode || settings?.defaultRunMode);
    if (isOverlayReason(reason)) {
      return { decision: mode === "preview" ? "preview_only" : "safe_remove", protectScore: 0, riskScore: 0, protectReasons: [], riskReasons: [] };
    }

    const profile = getProtectionProfile(el, reason, settings);
    const strong = mode === "strong";
    const preview = mode === "preview";
    const protectLimit = strong ? 9 : 6;
    const riskLimit = strong ? 5 : 3;

    if (profile.protectScore >= protectLimit || profile.riskScore > riskLimit) {
      return { decision: preview ? "protected" : "blocked", ...profile };
    }
    if (!strong && (profile.protectScore >= 4 || profile.riskScore >= 3)) {
      return { decision: "preview_only", ...profile };
    }
    return { decision: preview ? "preview_only" : "safe_remove", ...profile };
  }

  function markPreview(el, reason, classification) {
    if (!(el instanceof Element)) return false;
    if (el.hasAttribute(PREVIEW_ATTR)) return false;
    const decision = classification?.decision || "preview_only";
    const color = decision === "protected" || decision === "blocked" ? "#2563eb" : decision === "safe_remove" ? "#dc2626" : "#d97706";
    const rect = el.getBoundingClientRect();
    const outline = el.style.getPropertyValue("outline");
    const outlinePriority = el.style.getPropertyPriority("outline");
    const outlineOffset = el.style.getPropertyValue("outline-offset");
    const outlineOffsetPriority = el.style.getPropertyPriority("outline-offset");
    el.setAttribute(PREVIEW_ATTR, decision);
    el.style.setProperty("outline", `3px solid ${color}`, "important");
    el.style.setProperty("outline-offset", "2px", "important");

    const badge = document.createElement("div");
    badge.setAttribute(OWNED_ATTR, "preview-badge");
    badge.textContent = `OverlayKiller: ${reason}`;
    badge.style.cssText = [
      "position: fixed",
      `left: ${Math.max(8, Math.min(window.innerWidth - 240, rect.left))}px`,
      `top: ${Math.max(8, Math.min(window.innerHeight - 32, rect.top))}px`,
      `background: ${color}`,
      "color: #fff",
      "font: 12px/1.2 sans-serif",
      "padding: 4px 7px",
      "border-radius: 6px",
      "z-index: 2147483647",
      "pointer-events: none",
      "box-shadow: 0 3px 12px rgba(0,0,0,.25)"
    ].join(";");
    document.documentElement.appendChild(badge);
    previewArtifacts.push({
      el,
      badge,
      outline,
      outlinePriority,
      outlineOffset,
      outlineOffsetPriority
    });
    if (activeBatch) activeBatch.previewed.push({ el, reason, decision, classification });
    return true;
  }

  function isExtensionOwnedNode(el) {
    if (!(el instanceof Element)) return true;
    let node = el;
    const seen = new Set();
    while (node instanceof Element && !seen.has(node)) {
      seen.add(node);
      if (node.hasAttribute(OWNED_ATTR)) return true;
      if (node.parentElement instanceof Element) {
        node = node.parentElement;
        continue;
      }
      let host = null;
      try {
        host = node.getRootNode?.().host;
      } catch (_error) {
        host = null;
      }
      node = host instanceof Element ? host : null;
    }
    return false;
  }

  function isCandidateEligible(el) {
    return el instanceof Element && el.isConnected !== false && !isExtensionOwnedNode(el) && !el.hasAttribute(NEUTRALIZED_ATTR);
  }

  function clearPreviewArtifacts() {
    while (previewArtifacts.length > 0) {
      const item = previewArtifacts.pop();
      if (item.el instanceof Element) {
        item.el.removeAttribute(PREVIEW_ATTR);
        if (item.outline) item.el.style.setProperty("outline", item.outline, item.outlinePriority || "");
        else item.el.style.removeProperty("outline");
        if (item.outlineOffset) item.el.style.setProperty("outline-offset", item.outlineOffset, item.outlineOffsetPriority || "");
        else item.el.style.removeProperty("outline-offset");
      }
      if (item.badge?.isConnected) item.badge.remove();
    }
  }

  function broadcastToChildFrames(message) {
    for (const frame of document.querySelectorAll("iframe")) {
      try {
        frame.contentWindow?.postMessage({ ...message, __overlayKillerFrameCommand: true }, "*");
      } catch (_error) {
        // Cross-origin frames still accept postMessage when contentWindow is available.
      }
    }
  }

  function recordAndHide(el, reason = "unknown") {
    if (!isCandidateEligible(el)) return false;
    if (el.hasAttribute(HIDDEN_ATTR)) return false;
    const settings = activeBatch?.settings || DEFAULT_SETTINGS;
    const classification = classifyRemovalDecision(el, reason, settings);
    const mode = normalizeRunMode(settings.currentRunMode || settings.defaultRunMode);

    if (mode !== "preview" && classification.decision === "preview_only") {
      if (activeBatch) activeBatch.skipped.push({ el, reason, classification });
      if (mode !== "strong") return false;
    }

    if (classification.decision === "protected" && settings.previewProtectOutlines === false) {
      if (activeBatch) activeBatch.skipped.push({ el, reason, classification });
      return false;
    }

    if (mode === "preview" || classification.decision === "protected") {
      markPreview(el, reason, classification);
      if (classification.decision !== "safe_remove" && activeBatch) {
        activeBatch.skipped.push({ el, reason, classification });
      }
      if (mode !== "strong") return false;
    }

    if (classification.decision === "blocked") {
      if (activeBatch) activeBatch.skipped.push({ el, reason, classification });
      return false;
    }

    const prevStyle = el.getAttribute("style");
    const prevAria = el.getAttribute("aria-hidden");

    el.style.setProperty("display", "none", "important");
    el.setAttribute("aria-hidden", "true");
    el.setAttribute(HIDDEN_ATTR, "1");

    if (activeBatch) {
      activeBatch.hidden.push({ el, prevStyle, prevAria, reason });
    }
    return true;
  }

  function undoLast() {
    const batch = actionHistory.pop();
    if (!batch) return { ok: false, detail: "undo-empty" };

    let restored = 0;
    let linksRestored = 0;
    let linkConflicts = 0;
    for (let i = batch.scrollLocks.length - 1; i >= 0; i -= 1) {
      const item = batch.scrollLocks[i];
      if (!(item.el instanceof Element) || !item.el.isConnected) continue;
      if (item.value) {
        item.el.style.setProperty(item.prop, item.value, item.priority || "");
      } else {
        item.el.style.removeProperty(item.prop);
      }
    }

    for (let i = batch.hidden.length - 1; i >= 0; i -= 1) {
      const item = batch.hidden[i];
      const { el, prevStyle, prevAria } = item;
      if (!(el instanceof Element) || !el.isConnected) continue;

      if (prevStyle !== null) {
        el.setAttribute("style", prevStyle);
      } else {
        el.removeAttribute("style");
      }

      if (prevAria !== null) {
        el.setAttribute("aria-hidden", prevAria);
      } else {
        el.removeAttribute("aria-hidden");
      }

      el.removeAttribute(HIDDEN_ATTR);
      restored += 1;
    }

    for (let i = batch.neutralized.length - 1; i >= 0; i -= 1) {
      const item = batch.neutralized[i];
      const { original, replacement, parent, text } = item;
      if (!(original instanceof Element) || !(replacement instanceof Element) || !(parent instanceof Element)) {
        linkConflicts += 1;
        continue;
      }
      if (original.isConnected || replacement.parentElement !== parent || !replacement.hasAttribute(NEUTRALIZED_ATTR) || replacement.textContent !== text) {
        linkConflicts += 1;
        continue;
      }
      parent.replaceChild(original, replacement);
      linksRestored += 1;
    }

    if (batch.scrollRestore) {
      window.scrollTo(batch.scrollRestore.beforeX, batch.scrollRestore.beforeY);
    }

    rememberUndoProtection(batch);
    return {
      ok: restored > 0 || linksRestored > 0 || batch.scrollLocks.length > 0,
      detail: "undo-restored",
      restored,
      linksRestored,
      linkConflicts
    };
  }

  function rememberUndoProtection(batch) {
    const settings = batch?.settings || {};
    if (!settings.learnFromUndo || !chrome?.storage?.local) return;
    const host = getCurrentHost();
    if (!host) return;
    const hints = (batch.hidden || [])
      .map((item) => item.el)
      .filter((el) => el instanceof Element)
      .slice(0, 12)
      .map((el) => ({
        selectorHint: getSelectorHint(el),
        classTokens: Array.from(getClassTokenSet(el)).slice(0, 6),
        textSignature: getTextSignature(el),
        createdAt: new Date().toISOString()
      }))
      .filter((hint) => hint.selectorHint || hint.classTokens.length > 0 || hint.textSignature.length >= 24);

    if (hints.length === 0) return;
    chrome.storage.local.get({ siteRules: {} }, (data) => {
      const siteRules = data.siteRules && typeof data.siteRules === "object" ? data.siteRules : {};
      const current = siteRules[host] && typeof siteRules[host] === "object" ? siteRules[host] : {};
      const protectedHints = Array.isArray(current.protectedHints) ? current.protectedHints : [];
      siteRules[host] = {
        ...current,
        protectedHints: [...hints, ...protectedHints].slice(0, 60)
      };
      chrome.storage.local.set({ siteRules });
    });
  }

  function isBlockingOverflow(value) {
    return value === "hidden" || value === "clip";
  }

  function setScrollUnlockStyle(el, prop, value) {
    recordScrollState(el, prop);
    el.style.setProperty(prop, value, "important");
  }

  function clearScrollLock() {
    const html = document.documentElement;
    const body = document.body;
    const roots = new Set([html, body, document.scrollingElement]);
    let unlocked = 0;

    for (const el of roots) {
      if (!(el instanceof Element)) continue;
      const style = getComputedStyle(el);
      if (isBlockingOverflow(style.overflowY)) {
        setScrollUnlockStyle(el, "overflow-y", "auto");
        unlocked += 1;
      }
      if (style.touchAction === "none") {
        setScrollUnlockStyle(el, "touch-action", "auto");
        unlocked += 1;
      }
    }

    if (body instanceof Element) {
      const bodyStyle = getComputedStyle(body);
      if (bodyStyle.position === "fixed") {
        const beforeX = window.scrollX;
        const beforeY = window.scrollY;
        const lockedTop = Number.parseFloat(bodyStyle.top);
        const unlockedY = Number.isFinite(lockedTop) && lockedTop < 0 ? Math.round(-lockedTop) : beforeY;

        setScrollUnlockStyle(body, "position", "static");
        setScrollUnlockStyle(body, "top", "auto");
        if (activeBatch) {
          activeBatch.scrollRestore = { beforeX, beforeY };
        }
        window.scrollTo(beforeX, unlockedY);
        unlocked += 1;
      }
    }

    return unlocked;
  }

  function registerShadowRoot(sr) {
    if (!sr || shadowRoots.has(sr)) return;
    shadowRoots.add(sr);
  }

  function scanOpenShadowRoots(rootNode) {
    if (!rootNode) return;
    const walker = document.createTreeWalker(rootNode, NodeFilter.SHOW_ELEMENT);
    let node = walker.currentNode;
    while (node) {
      const el = node;
      if (el.shadowRoot) registerShadowRoot(el.shadowRoot);
      node = walker.nextNode();
    }
  }

  function setupShadowTracking() {
    if (shadowTrackingReady) return;
    shadowTrackingReady = true;

    const original = Element.prototype.attachShadow;
    if (!Element.prototype[SHADOW_PATCH_ATTR]) {
      Element.prototype.attachShadow = function attachShadowPatched(init) {
        const sr = original.call(this, init);
        if (init && init.mode === "open") registerShadowRoot(sr);
        return sr;
      };
      Object.defineProperty(Element.prototype, SHADOW_PATCH_ATTR, {
        value: true,
        configurable: false,
        writable: false,
        enumerable: false
      });
    }

    scanOpenShadowRoots(document);
  }

  function collectAllElements() {
    setupShadowTracking();
    scanOpenShadowRoots(document);

    const elements = [];
    const seen = new Set();
    const addAll = (nodes) => {
      for (const node of nodes) {
        if (!isCandidateEligible(node) || seen.has(node)) continue;
        seen.add(node);
        elements.push(node);
      }
    };
    let bodyCount = 0;
    let htmlOutsideBodyCount = 0;
    let shadowCount = 0;
    if (document.body) {
      const bodyNodes = document.body.querySelectorAll("*");
      bodyCount = bodyNodes.length;
      addAll(bodyNodes);
    }

    // Browsers permit ad hosts to append visual nodes directly under <html>.
    // Do not traverse HEAD/BODY themselves: only their non-document siblings.
    for (const child of Array.from(document.documentElement?.children || [])) {
      if (child === document.head || child === document.body) continue;
      const outsideNodes = [child, ...child.querySelectorAll("*")];
      htmlOutsideBodyCount += outsideNodes.length;
      addAll(outsideNodes);
    }

    for (const sr of shadowRoots) {
      try {
        if (sr && sr.host && sr.isConnected) {
          const shadowNodes = sr.querySelectorAll("*");
          shadowCount += shadowNodes.length;
          addAll(shadowNodes);
        }
      } catch (_error) {
        // ignore detached roots
      }
    }
    return { elements, counts: { body: bodyCount, htmlOutsideBody: htmlOutsideBodyCount, shadow: shadowCount } };
  }

  function hasHiddenAncestor(el) {
    return el instanceof Element && Boolean(el.closest(`[${HIDDEN_ATTR}='1']`));
  }

  function getVerifiedGoogleProtection(el, reason, settings) {
    const mainEl = findMainContent();
    const content = getContentLikelihood(el, mainEl);
    let protectScore = content.score;
    const protectReasons = [...content.reasons];
    let riskScore = 0;
    const riskReasons = [];

    // A verified, short annotation chip may live under article content.  Only
    // those inherited points are exempt; the chip's own safety boundaries stay.
    if (reason === "google-annotation-chip") {
      if (content.reasons.includes("article-markers")) protectScore -= 3;
      if (content.reasons.includes("main-related")) protectScore -= 2;
      protectReasons.push("chip-ancestor-content-exempt");
    }
    if (isProtectedContentTree(el, mainEl)) {
      protectScore += 4;
      protectReasons.push("protected-content-tree");
    }
    if (el.matches("main, article, [role='main'], form, nav, header, footer") || el.querySelector("form, input, textarea, select")) {
      protectScore += 3;
      protectReasons.push("major-ui-or-form");
    }
    if (getTextLength(el) >= 280) {
      protectScore += 4;
      protectReasons.push("long-self-text");
    }
    if (document.activeElement instanceof Element && (el === document.activeElement || el.contains(document.activeElement))) {
      protectScore += 5;
      protectReasons.push("active-user-focus");
    }
    if (isNearVideoOrCanvas(el) && !isAdVideoContainer(el)) {
      protectScore += 3;
      riskScore += 2;
      protectReasons.push("normal-video-or-canvas");
    }
    if (getRectArea(el.getBoundingClientRect()) / getViewportArea() > 0.55) {
      riskScore += 3;
      riskReasons.push("large-page-area");
    }
    const learned = getSavedSiteRules(settings).protectedHints || [];
    if (learned.some((hint) => matchesLearnedHint(el, hint))) {
      protectScore += 5;
      protectReasons.push("learned-protection");
    }
    return { protectScore, riskScore, protectReasons, riskReasons };
  }

  function recordVerifiedGoogleAd(el, reason) {
    if (!isCandidateEligible(el) || el.hasAttribute(HIDDEN_ATTR)) return false;
    const settings = activeBatch?.settings || DEFAULT_SETTINGS;
    const mode = normalizeRunMode(settings.currentRunMode || settings.defaultRunMode);
    const protection = getVerifiedGoogleProtection(el, reason, settings);
    if (protection.protectScore >= 6 || protection.riskScore >= 3) {
      if (activeBatch) activeBatch.skipped.push({ el, reason, classification: { decision: "blocked", ...protection } });
      return false;
    }
    if (mode === "preview") {
      return markPreview(el, reason, { decision: "safe_remove", protectScore: 0, riskScore: 0 });
    }
    const prevStyle = el.getAttribute("style");
    const prevAria = el.getAttribute("aria-hidden");
    el.style.setProperty("display", "none", "important");
    el.setAttribute("aria-hidden", "true");
    el.setAttribute(HIDDEN_ATTR, "1");
    if (activeBatch) activeBatch.hidden.push({ el, prevStyle, prevAria, reason });
    return true;
  }

  function removeGoogleHtmlRootAds(elements) {
    let candidates = 0;
    let removed = 0;
    for (const el of elements) {
      if (!isCandidateEligible(el) || el.tagName !== "INS" || el.parentElement !== document.documentElement) continue;
      if (!el.classList.contains("adsbygoogle") || !isElementVisible(el) || hasHiddenAncestor(el)) continue;
      const style = getComputedStyle(el);
      if (style.position !== "fixed" || !hasDirectAdSignature(el)) continue;
      candidates += 1;
      if (recordVerifiedGoogleAd(el, "google-html-root-ad")) removed += 1;
    }
    return { candidates, removed };
  }

  function getGoogleAnchorSignals(el) {
    const signals = new Set();
    const own = `${el.id || ""} ${(el.className || "").toString()}`.toLowerCase();
    if (/google-anno|google-side-rail-overlap|google-anchor-overlappable/.test(own)) signals.add("google-anchor-class");
    for (const node of el.querySelectorAll("[aria-label], [title]")) {
      const label = `${node.getAttribute("aria-label") || ""} ${node.getAttribute("title") || ""}`.toLowerCase();
      if (/shopping anchor|ショッピング\s*アンカー/.test(label)) signals.add("shopping-anchor-close-label");
      if (node.tagName === "SVG" && (node.getAttribute("role") || "").toLowerCase() === "button") signals.add("svg-close-control");
    }
    return signals;
  }

  function removeGoogleShoppingAnchors(elements) {
    let candidates = 0;
    let removed = 0;
    for (const el of elements) {
      if (!isCandidateEligible(el) || el.id !== "google-anno-sa" || !isElementVisible(el) || hasHiddenAncestor(el)) continue;
      const style = getComputedStyle(el);
      const rect = el.getBoundingClientRect();
      if (style.position !== "fixed" || rect.width <= 0 || rect.height <= 0 || getTextLength(el) > INLINE_TEXT_LIMIT) continue;
      if (el.querySelector("form, input, textarea, select, h1, h2, h3, h4, p")) continue;
      const signals = getGoogleAnchorSignals(el);
      if (signals.size < 2) continue;
      candidates += 1;
      // SVG controls are evidence only. This path never clicks a page control.
      if (recordVerifiedGoogleAd(el, "google-shopping-anchor")) removed += 1;
    }
    return { candidates, removed };
  }

  function removeGoogleAnnotationChips(elements) {
    let candidates = 0;
    let removed = 0;
    for (const el of elements) {
      if (!isCandidateEligible(el) || !el.classList.contains("google-anno-sc") || el.getAttribute("role") !== "link") continue;
      if (!isElementVisible(el) || hasHiddenAncestor(el) || getTextLength(el) > INLINE_TEXT_LIMIT) continue;
      if (el.getAttribute("data-google-vignette") !== "false" || el.getAttribute("data-google-interstitial") !== "false") continue;
      if (el.querySelector("form, input, textarea, select, h1, h2, h3, h4, p, article, main")) continue;
      candidates += 1;
      if (recordVerifiedGoogleAd(el, "google-annotation-chip")) removed += 1;
    }
    return { candidates, removed };
  }

  function isNeutralizableGoogleAnnotationLink(link) {
    if (!isCandidateEligible(link) || link.tagName !== "A" || !link.classList.contains("google-anno") || link.hasAttribute(NEUTRALIZED_ATTR)) return false;
    const label = link.querySelector(":scope > .google-anno-t");
    if (!(label instanceof Element) || label.tagName !== "SPAN" || link.children.length !== 1 || label.children.length > 0) return false;
    if (!label.textContent || link.closest("form, [contenteditable='true']")) return false;
    if (document.activeElement instanceof Element && (link === document.activeElement || link.contains(document.activeElement))) return false;
    const selection = document.getSelection?.();
    if (selection?.rangeCount && link.contains(selection.getRangeAt(0).commonAncestorContainer)) return false;
    return true;
  }

  function neutralizeGoogleAnnotationLinks(elements) {
    let candidates = 0;
    let neutralized = 0;
    const mode = normalizeRunMode(activeBatch?.settings?.currentRunMode || activeBatch?.settings?.defaultRunMode);
    for (const link of elements) {
      if (!isNeutralizableGoogleAnnotationLink(link)) continue;
      candidates += 1;
      if (mode === "preview") {
        if (markPreview(link, "google-annotation-link", { decision: "safe_remove", protectScore: 0, riskScore: 0 })) neutralized += 1;
        continue;
      }
      const parent = link.parentElement;
      if (!(parent instanceof Element)) continue;
      const replacement = document.createElement("span");
      const text = link.firstElementChild.textContent;
      replacement.textContent = text;
      replacement.setAttribute(NEUTRALIZED_ATTR, "1");
      parent.replaceChild(replacement, link);
      activeBatch?.neutralized.push({ original: link, replacement, parent, text });
      neutralized += 1;
    }
    return { candidates, neutralized };
  }

  function tokenize(value) {
    return (value || "")
      .toLowerCase()
      .split(/[^a-z0-9]+/)
      .map((v) => v.trim())
      .filter((v) => v.length >= 2 && v.length <= 40);
  }


  function normalizeHostHint(value) {
    const raw = (value || "").trim().toLowerCase();
    if (!raw) return null;
    const withoutScheme = raw.replace(/^https?:\/\//, "");
    const cleaned = withoutScheme.replace(/^[|]+/, "").replace(/[\^*]+$/g, "");
    return cleaned || null;
  }

  function isHostLikeHint(value) {
    const normalized = normalizeHostHint(value);
    return Boolean(normalized && /(?:^|\.)[a-z0-9-]+\.[a-z]{2,}/.test(normalized));
  }

  function extractUrlHost(value) {
    const normalized = normalizeHostHint(value);
    if (!normalized) return null;
    try {
      const url = normalized.startsWith("http://") || normalized.startsWith("https://") ? new URL(normalized) : new URL(`https://${normalized}`);
      return (url.host || "").toLowerCase();
    } catch (_error) {
      const host = normalized.split("/")[0] || "";
      return host.toLowerCase() || null;
    }
  }

  function collectUrlLikeValues(el) {
    if (!(el instanceof Element)) return [];
    const values = [];
    const pushValue = (v) => {
      if (!v) return;
      values.push(v);
    };

    pushValue(el.getAttribute("src") || "");
    pushValue(el.getAttribute("href") || "");
    for (const attr of el.getAttributeNames()) {
      pushValue(el.getAttribute(attr) || "");
    }

    const descendants = el.querySelectorAll("a[href], iframe[src], img[src], video[src], script[src], source[src]");
    for (const node of descendants) {
      pushValue(node.getAttribute("href") || "");
      pushValue(node.getAttribute("src") || "");
      for (const attr of node.getAttributeNames()) {
        pushValue(node.getAttribute(attr) || "");
      }
    }
    return values;
  }

  function isSafeDismissControl(node) {
    if (!(node instanceof HTMLElement)) return false;
    if (!isElementVisible(node)) return false;
    if (node.hasAttribute("href") || node.matches("a, area, [role='link']")) return false;

    const tag = (node.tagName || "").toUpperCase();
    const role = (node.getAttribute("role") || "").toLowerCase();
    const inputType = (node.getAttribute("type") || "").toLowerCase();
    return tag === "BUTTON" || role === "button" || (tag === "INPUT" && ["button", "reset"].includes(inputType));
  }

  function findCloseButton(target) {
    const selectors = [
      "button[aria-label*='close' i]",
      "button[aria-label*='閉じ' i]",
      "button[title*='close' i]",
      "button[title*='閉じ' i]",
      "[role='button'][aria-label*='close' i]",
      "[role='button'][aria-label*='閉じ' i]",
      "button[class*='close' i]",
      "[role='button'][class*='close' i]",
      "button",
      "[role='button']"
    ];

    const exactTextHints = new Set(["close", "閉じる", "閉じ", "dismiss", "×", "✕", "✖"]);

    for (const selector of selectors) {
      const nodes = target.querySelectorAll(selector);
      for (const node of nodes) {
        if (!isSafeDismissControl(node)) continue;

        const text = (node.textContent || "").replace(/\s+/g, " ").trim().toLowerCase();
        const aria = (node.getAttribute("aria-label") || "").toLowerCase();
        const title = (node.getAttribute("title") || "").toLowerCase();
        const cls = (node.className || "").toString().toLowerCase();

        const semanticMatched = /close|dismiss|閉じ/.test(`${aria} ${title} ${cls}`);
        const matched = semanticMatched || exactTextHints.has(text);
        if (matched) return node;
      }
    }

    return null;
  }

  function findCollapseControl(target) {
    const selectors = [
      "button",
      "[role='button']"
    ];
    const arrowChars = ["▼", "▲", "◀", "▶", "▾", "▴", "‹", "›", "«", "»", "∨", "∧"];
    const hintWords = ["collapse", "minimize", "minimise", "hide", "toggle", "slide", "drawer", "close", "閉じ", "隠", "しま", "収納"];

    for (const selector of selectors) {
      const nodes = target.querySelectorAll(selector);
      for (const node of nodes) {
        if (!isSafeDismissControl(node)) continue;

        const text = (node.textContent || "").trim();
        const aria = (node.getAttribute("aria-label") || "").toLowerCase();
        const title = (node.getAttribute("title") || "").toLowerCase();
        const cls = (node.className || "").toString().toLowerCase();
        const matchedWord = hintWords.some((w) => aria.includes(w) || title.includes(w) || cls.includes(w));
        const matchedArrow = arrowChars.includes(text) || (text.length <= 2 && [...text].some((ch) => arrowChars.includes(ch)));
        if (matchedWord || matchedArrow) return node;
      }
    }

    return null;
  }


  function hasDismissControl(target) {
    return Boolean(findCloseButton(target) || findCollapseControl(target));
  }

  function isDockedEdgePosition(rect) {
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const nearBottom = rect.bottom >= vh - 24;
    const nearTop = rect.top <= 24;
    const nearLeft = rect.left <= 24;
    const nearRight = rect.right >= vw - 24;
    const bottomTopBand = (nearBottom || nearTop) && rect.width >= vw * 0.28 && rect.height >= 50 && rect.height <= vh * 0.45;
    const sideBand = (nearLeft || nearRight) && rect.height >= vh * 0.24 && rect.width >= 80 && rect.width <= vw * 0.45;
    const cornerFloat = nearBottom && (nearLeft || nearRight) && rect.width >= 120 && rect.width <= vw * 0.22 && rect.height >= 90 && rect.height <= vh * 0.28;
    return { nearBottom, nearTop, nearLeft, nearRight, matched: bottomTopBand || sideBand || cornerFloat, bottomTopBand, sideBand, cornerFloat };
  }


  function isSideRailPosition(rect, mainRect) {
    if (!rect || !mainRect) return false;
    const vw = window.innerWidth;
    const horizontalGap = Math.max(16, vw * 0.02);
    const leftRail = rect.right <= mainRect.left - horizontalGap;
    const rightRail = rect.left >= mainRect.right + horizontalGap;
    const verticallyAligned = rect.bottom >= mainRect.top - 120 && rect.top <= mainRect.bottom + 120;
    const edgeAnchored = rect.left <= 64 || rect.right >= vw - 64;
    return (leftRail || rightRail || edgeAnchored) && verticallyAligned;
  }

  function hasSizeSignal(el, rect) {
    const w = rect.width;
    const h = rect.height;
    const area = getRectArea(rect);

    const near = (a, b, tolerance) => Math.abs(a - b) <= tolerance;
    const matchClassic =
      (near(w, 300, 36) && near(h, 250, 30)) ||
      (near(w, 320, 36) && near(h, 100, 28)) ||
      (near(w, 728, 72) && near(h, 90, 24)) ||
      (near(w, 970, 96) && near(h, 250, 40)) ||
      (near(w, 160, 24) && near(h, 600, 80));

    const matchAreaBand = area >= 12000 && area <= 220000;
    return matchClassic || matchAreaBand;
  }

  function hasTagSignal(el) {
    const tag = el.tagName;
    return tag === "IFRAME" || tag === "INS" || tag === "ASIDE";
  }

  function hasPositionSignal(el, rect) {
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const rightRail = rect.left >= vw * 0.6 && rect.width <= vw * 0.42;
    const inMiddle = rect.top >= vh * 0.12 && rect.top <= vh * 0.88;
    const medium = rect.width <= vw * 0.96 && rect.height <= vh * 0.45;
    const articleLike = Boolean(el.closest("article, main, [role='main']"));
    return rightRail || (articleLike && inMiddle && medium);
  }

  function hasAttributeSignal(el) {
    const ariaLabel = (el.getAttribute("aria-label") || "").toLowerCase();
    const role = (el.getAttribute("role") || "").toLowerCase();
    if (ariaLabel.includes("advertisement") || ariaLabel.includes("sponsored")) return true;
    if (role.includes("complementary") && ariaLabel.includes("ad")) return true;

    for (const attr of el.getAttributeNames()) {
      const n = attr.toLowerCase();
      const v = (el.getAttribute(attr) || "").toLowerCase();
      if (n.startsWith("data-ad") || n.includes("sponsor") || v.includes("adsbygoogle")) return true;
    }
    return false;
  }

  function hasVocabSignal(el, vocabSet) {
    if (!vocabSet || vocabSet.size === 0) return false;

    const parts = [];
    parts.push(el.id || "");
    parts.push((el.className || "").toString());
    parts.push(el.getAttribute("aria-label") || "");
    parts.push(el.getAttribute("name") || "");
    parts.push(el.getAttribute("src") || "");
    parts.push(el.getAttribute("href") || "");

    for (const attr of el.getAttributeNames()) {
      if (attr.startsWith("data-") || attr.includes("ad") || attr.includes("sponsor")) {
        parts.push(attr);
        parts.push(el.getAttribute(attr) || "");
      }
    }

    const joined = parts.join(" ").toLowerCase();
    const tokens = tokenize(joined);
    return tokens.some((t) => vocabSet.has(t));
  }

  function hasDirectAdSignature(el) {
    if (!(el instanceof Element)) return false;
    const directPatterns = [
      "googleads",
      "adchoices",
      "adsystem",
      "doubleclick",
      "googlesyndication",
      "adsbygoogle",
      "pagead2",
      "securepubads",
      "adservice",
      "adserver",
      "adpushup",
      "jma-ad",
      "wap-player",
      "google_ads_iframe",
      "google_ads_iframe_",
      "aswift_",
      "google_sdk_frame",
      "ima-ad-container",
      "apclosebutton",
      "ap-float-close-btn",
      "videowrapperdiv",
      "adswift",
      "side-rail-dismiss-btn",
      "side-rail-edge",
      "doubleclick.net/pagead"
    ];

    const parts = [];
    parts.push(el.id || "");
    parts.push((el.className || "").toString());
    parts.push(el.getAttribute("src") || "");
    parts.push(el.getAttribute("href") || "");
    parts.push(el.getAttribute("aria-label") || "");

    for (const attr of el.getAttributeNames()) {
      parts.push(attr);
      parts.push(el.getAttribute(attr) || "");
    }

    const joined = parts.join(" ").toLowerCase();
    return directPatterns.some((pattern) => joined.includes(pattern));
  }


  function hasAdHostSignal(el, hostHints) {
    if (!(el instanceof Element) || !(hostHints instanceof Set) || hostHints.size === 0) return false;
    const hosts = new Set();
    for (const value of collectUrlLikeValues(el)) {
      const host = extractUrlHost(value);
      if (host) hosts.add(host);
    }
    for (const host of hosts) {
      for (const hint of hostHints) {
        if (host === hint || host.endsWith(`.${hint}`) || hint.endsWith(`.${host}`)) {
          return true;
        }
      }
    }
    return false;
  }


  function getAbsoluteAdLinkBundleInfo(el, hostHints) {
    if (!(el instanceof Element)) return { matched: false, score: 0, container: null };
    const links = Array.from(el.querySelectorAll("a[href]")).filter((link) => link instanceof Element);
    if (links.length < 3) return { matched: false, score: 0, container: null };

    let absoluteCount = 0;
    let hostMatched = 0;
    let targetBlank = 0;
    const sizeBuckets = new Map();

    for (const link of links) {
      const style = getComputedStyle(link);
      const rect = link.getBoundingClientRect();
      if (rect.width < 80 || rect.height < 60) continue;
      if (style.position === "absolute" || style.position === "fixed") {
        absoluteCount += 1;
      }
      if ((link.getAttribute("target") || "").toLowerCase() === "_blank") {
        targetBlank += 1;
      }
      if (hasDirectAdSignature(link) || hasAdHostSignal(link, hostHints)) {
        hostMatched += 1;
      }
      const key = `${Math.round(rect.width / 12)}x${Math.round(rect.height / 12)}`;
      sizeBuckets.set(key, (sizeBuckets.get(key) || 0) + 1);
    }

    const maxBucket = Math.max(0, ...sizeBuckets.values());
    const clsId = `${el.id || ""} ${(el.className || "").toString()}`.toLowerCase();
    const offerLike = /alloffers|offer-container|offer\d+|price-set|banner-clickholder/.test(clsId);
    const matched = hostMatched >= 3 && absoluteCount >= 3 && (maxBucket >= 3 || targetBlank >= 3 || offerLike);
    let score = 0;
    if (matched) {
      score += 4;
      if (offerLike) score += 2;
      if (targetBlank >= 3) score += 1;
      if (maxBucket >= 4) score += 1;
    }
    return { matched, score, container: matched ? el : null };
  }

  function rectIntersectionArea(rectA, rectB) {
    if (!rectA || !rectB) return 0;
    const left = Math.max(rectA.left, rectB.left);
    const right = Math.min(rectA.right, rectB.right);
    const top = Math.max(rectA.top, rectB.top);
    const bottom = Math.min(rectA.bottom, rectB.bottom);
    if (right <= left || bottom <= top) return 0;
    return (right - left) * (bottom - top);
  }

  function getOverlapRatio(mainRect, candRect) {
    const intersectionArea = rectIntersectionArea(mainRect, candRect);
    const areaMain = getRectArea(mainRect);
    const areaCand = getRectArea(candRect);
    const baseArea = Math.max(1, Math.min(areaMain, areaCand));
    return intersectionArea / baseArea;
  }

  function hasStackingContextHint(el) {
    if (!(el instanceof Element)) return false;

    let current = el.parentElement;
    let depth = 0;
    while (current && depth < STACKING_SCAN_MAX_DEPTH) {
      const style = getComputedStyle(current);
      const opacity = Number.parseFloat(style.opacity || "1");
      const hasWillChangeHint = (style.willChange || "").toLowerCase().split(",").some((v) => {
        const t = v.trim();
        return t === "transform" || t === "opacity" || t === "filter";
      });

      if (
        opacity < 1 ||
        style.transform !== "none" ||
        style.filter !== "none" ||
        style.perspective !== "none" ||
        style.mixBlendMode !== "normal" ||
        style.isolation === "isolate" ||
        style.position === "fixed" ||
        hasWillChangeHint
      ) {
        return true;
      }

      current = current.parentElement;
      depth += 1;
    }
    return false;
  }

  function hasClickableHint(el) {
    if (!(el instanceof Element)) return { matched: false, decorativeOnly: false };
    const style = getComputedStyle(el);
    const cursorPointer = style.cursor === "pointer";
    const clickableNode =
      el.matches("a, button, [role='link'], [onclick]") ||
      Boolean(el.querySelector("a, button, [role='link'], [onclick]"));

    const decorativeOnly = style.pointerEvents === "none" && !cursorPointer && !clickableNode;
    return { matched: cursorPointer || clickableNode, decorativeOnly };
  }

  function getTextLength(el) {
    const text = (el.textContent || "").replace(/\s+/g, " ").trim();
    return text.length;
  }

  function getArticleMarkerCount(el) {
    if (!(el instanceof Element)) return 0;

    let score = 0;
    if (el.matches(ARTICLE_MARKER_SELECTOR)) score += 2;
    if (el.querySelector(ARTICLE_MARKER_SELECTOR)) score += 2;
    if (el.closest(ARTICLE_MARKER_SELECTOR)) score += 2;

    const clsId = `${el.id || ""} ${(el.className || "").toString()}`.toLowerCase();
    if (/(^|[^a-z])(article|entry|post|archive|feed)([^a-z]|$)/.test(clsId)) score += 1;
    if (/(articlebody|entrycontent|postcontent|articlecontent|maincontent)/.test(clsId)) score += 1;
    return score;
  }

  function hasArticleStructure(el) {
    if (!(el instanceof Element)) return false;
    if (el.matches(ARTICLE_STRUCTURE_SELECTOR)) return true;
    return Boolean(el.querySelector(ARTICLE_STRUCTURE_SELECTOR));
  }

  function isProtectedContentTree(el, mainEl = null) {
    if (!(el instanceof Element)) return false;

    const markerScore = getArticleMarkerCount(el);
    if (markerScore >= 3) return true;
    if (markerScore >= 2 && hasArticleStructure(el)) return true;

    const textLength = getTextLength(el);
    const paragraphCount = el.querySelectorAll("p").length;
    const headingCount = el.querySelectorAll("h1, h2, h3, h4").length;
    const timeCount = el.querySelectorAll("time").length;
    const linkCount = el.querySelectorAll("a").length;
    const mediaCount = el.querySelectorAll("img, iframe, ins").length;

    if (headingCount >= 1 && (paragraphCount >= 1 || timeCount >= 1)) return true;
    if (paragraphCount >= 3 && textLength >= 220) return true;
    if (timeCount >= 1 && textLength >= 120) return true;
    if (mainEl instanceof Element && (el === mainEl || el.contains(mainEl) || mainEl.contains(el))) {
      if (textLength >= 180 || paragraphCount >= 2 || headingCount >= 1) return true;
    }
    if (textLength >= 320 && linkCount >= 3 && mediaCount <= linkCount + 2) return true;
    return false;
  }

  function isAdLikeWrapper(el) {
    if (!(el instanceof Element)) return false;
    const textLength = getTextLength(el);
    const clsId = `${el.id || ""} ${(el.className || "").toString()}`.toLowerCase();
    const childCount = el.childElementCount;
    const mediaCount = el.querySelectorAll("img, iframe, ins").length;
    return (
      hasAttributeSignal(el) ||
      /(^|[^a-z])(ad|ads|sponsor|promo|banner)([^a-z]|$)/.test(clsId) ||
      (textLength <= INLINE_TEXT_LIMIT && childCount <= 4 && mediaCount >= 1 && !hasArticleStructure(el))
    );
  }
  function getContentLikelihood(el, mainEl = null) {
    if (!(el instanceof Element)) return { score: 0, reasons: [] };

    let score = 0;
    const reasons = [];
    const textLength = getTextLength(el);
    const paragraphCount = el.querySelectorAll("p").length;
    const headingCount = el.querySelectorAll("h1, h2, h3, h4").length;
    const timeCount = el.querySelectorAll("time").length;
    const listCount = el.querySelectorAll("ul, ol, li").length;
    const linkCount = el.querySelectorAll("a").length;
    const imageCount = el.querySelectorAll("img").length;
    const articleMarkers = getArticleMarkerCount(el);

    if (textLength >= 280) {
      score += 2;
      reasons.push("long-text");
    }
    if (paragraphCount >= 2) {
      score += 2;
      reasons.push("paragraphs");
    }
    if (headingCount >= 1) {
      score += 2;
      reasons.push("headings");
    }
    if (timeCount >= 1) {
      score += 1;
      reasons.push("time");
    }
    if (listCount >= 3) {
      score += 1;
      reasons.push("lists");
    }
    if (articleMarkers >= 1) {
      score += 3;
      reasons.push("article-markers");
    }
    if (mainEl instanceof Element && (el === mainEl || el.contains(mainEl) || mainEl.contains(el))) {
      score += 2;
      reasons.push("main-related");
    }

    if (linkCount >= 6 && textLength >= 220) {
      score += 1;
      reasons.push("link-dense-text");
    }
    if (imageCount >= 3 && textLength >= 180) {
      score += 1;
      reasons.push("media-with-text");
    }

    return { score, reasons };
  }

  function shouldSuppressForContentLikelihood(el, options = {}) {
    const { mainEl = null, maxScore = 3, allowShortText = false } = options;
    if (isProtectedContentTree(el, mainEl)) {
      const content = getContentLikelihood(el, mainEl);
      return { suppress: true, score: Math.max(content.score, maxScore + 1), reasons: [...content.reasons, "protected-content-tree"] };
    }
    const content = getContentLikelihood(el, mainEl);
    if (allowShortText && getTextLength(el) <= INLINE_TEXT_LIMIT) {
      return { suppress: false, score: content.score, reasons: content.reasons };
    }
    return {
      suppress: content.score > maxScore,
      score: content.score,
      reasons: content.reasons
    };
  }

  function hasInlineIframeHint(el) {
    return hasTagSignal(el) || Boolean(el.querySelector("iframe, ins, aside"));
  }

  function isInteractiveChrome(el) {
    return Boolean(el.closest("header, nav, footer, [role='navigation']"));
  }

  function isWithinMainFlow(el, mainEl) {
    if (!(el instanceof Element) || !(mainEl instanceof Element)) return false;
    return el === mainEl || mainEl.contains(el);
  }

  function getDomDepth(el) {
    let depth = 0;
    let current = el;
    while (current && current.parentElement) {
      current = current.parentElement;
      depth += 1;
      if (depth >= 64) break;
    }
    return depth;
  }

  function getClassTokenSet(el) {
    return new Set(
      ((el.className || "").toString().toLowerCase().match(/[a-z0-9_-]{2,}/g) || []).filter(Boolean)
    );
  }

  function getRailSignature(el, rect) {
    return {
      width: Math.round(rect.width),
      height: Math.round(rect.height),
      depth: getDomDepth(el),
      classTokens: getClassTokenSet(el),
      imgCount: el.querySelectorAll("img").length,
      linkCount: el.querySelectorAll("a").length,
      iframeCount: el.querySelectorAll("iframe, ins").length
    };
  }

  function getSideRailSimilarityBonus(signature, signatures) {
    let bestBonus = 0;
    for (const other of signatures) {
      if (other === signature) continue;
      let bonus = 0;
      if (Math.abs(signature.width - other.width) <= 24 && Math.abs(signature.height - other.height) <= 60) {
        bonus += 1;
      }
      if (Math.abs(signature.depth - other.depth) <= 2) {
        bonus += 1;
      }
      const sharedClasses = [...signature.classTokens].filter((token) => other.classTokens.has(token));
      if (sharedClasses.length >= 1) {
        bonus += 1;
      }
      if (
        signature.imgCount === other.imgCount &&
        signature.linkCount === other.linkCount &&
        signature.iframeCount === other.iframeCount &&
        signature.imgCount + signature.linkCount + signature.iframeCount > 0
      ) {
        bonus += 1;
      }
      if (bonus > bestBonus) bestBonus = bonus;
    }
    return Math.min(2, bestBonus);
  }

  function findMainContent() {
    const selectors = ["main", "article", "[role='main']", "#main", ".main", ".content", ".article", ".entry-content", ".post-content"];
    const unique = new Set();
    const candidates = [];
    const viewportArea = getViewportArea();
    const viewportCenterX = window.innerWidth / 2;

    for (const selector of selectors) {
      const found = document.querySelectorAll(selector);
      for (const el of found) {
        if (!(el instanceof Element)) continue;
        if (unique.has(el)) continue;
        unique.add(el);
        if (!isElementVisible(el)) continue;

        const rect = el.getBoundingClientRect();
        const area = getRectArea(rect);
        if (area < viewportArea * 0.06) continue;
        if (rect.width < window.innerWidth * 0.26) continue;
        if (rect.right < viewportCenterX - window.innerWidth * 0.08 || rect.left > viewportCenterX + window.innerWidth * 0.08) continue;

        const textLength = Math.min(getTextLength(el), 6000);
        const centerX = rect.left + rect.width / 2;
        const centerPenalty = Math.abs(centerX - viewportCenterX) / Math.max(1, window.innerWidth);
        const content = getContentLikelihood(el, null);
        const markerScore = getArticleMarkerCount(el);
        const paragraphCount = el.querySelectorAll("p").length;
        const headingCount = el.querySelectorAll("h1, h2, h3").length;
        const score =
          area +
          textLength * 45 +
          content.score * 50000 +
          markerScore * 70000 +
          paragraphCount * 12000 +
          headingCount * 8000 -
          centerPenalty * 220000;
        candidates.push({ el, score });
      }
    }

    candidates.sort((a, b) => b.score - a.score);
    return candidates.length > 0 ? candidates[0].el : null;
  }
  function getRemovableTarget(el, mainEl = null) {
    if (!(el instanceof Element)) return el;
    if (isProtectedContentTree(el, mainEl)) return el;

    if (el.tagName === "IFRAME" || el.tagName === "INS") {
      const p = el.parentElement;
      if (p && p !== document.body && p !== document.documentElement && !isProtectedContentTree(p, mainEl) && isAdLikeWrapper(p)) {
        const rect = p.getBoundingClientRect();
        const area = getRectArea(rect);
        if (area <= getViewportArea() * 0.45 && getTextLength(p) <= INLINE_TEXT_LIMIT) return p;
      }
    }

    if (mainEl instanceof Element) {
      const parent = el.parentElement;
      if (
        parent &&
        parent !== mainEl &&
        !isInteractiveChrome(parent) &&
        !isProtectedContentTree(parent, mainEl) &&
        isAdLikeWrapper(parent) &&
        parent.childElementCount <= 4 &&
        getTextLength(parent) <= INLINE_TEXT_LIMIT &&
        !parent.querySelector(ARTICLE_STRUCTURE_SELECTOR)
      ) {
        const parentRect = parent.getBoundingClientRect();
        const currentRect = el.getBoundingClientRect();
        if (getRectArea(parentRect) <= getRectArea(currentRect) * 1.8) return parent;
      }
    }

    return el;
  }


  function getDockedTarget(el, mainEl = null) {
    if (!(el instanceof Element)) return el;
    let current = el;
    let depth = 0;
    while (current && current !== document.body && current !== document.documentElement && depth < 6) {
      if (isProtectedContentTree(current, mainEl)) break;
      const style = getComputedStyle(current);
      const rect = current.getBoundingClientRect();
      const dock = isDockedEdgePosition(rect);
      if ((style.position === "fixed" || style.position === "sticky") && dock.matched) {
        return current;
      }
      if (
        style.position === "absolute" &&
        dock.matched &&
        (hasDirectAdSignature(current) || hasAttributeSignal(current) || hasDismissControl(current))
      ) {
        return current;
      }
      current = current.parentElement;
      depth += 1;
    }
    return getRemovableTarget(el, mainEl);
  }
  function findOverlayCandidates(elements) {
    const viewportArea = getViewportArea();
    const candidates = [];

    for (const el of elements) {
      if (shouldSkipForRemoval(el)) continue;

      const style = getComputedStyle(el);
      if (style.display === "none" || style.visibility === "hidden" || style.contentVisibility === "hidden") continue;
      if (style.position !== "fixed" && style.position !== "absolute") continue;

      const zIndex = parseNumber(style.zIndex, 0);
      if (zIndex < OVERLAY_MIN_Z_INDEX) continue;

      const rect = el.getBoundingClientRect();
      if (rect.width < 4 || rect.height < 4) continue;
      const area = getRectArea(rect);
      const areaRatio = area / viewportArea;
      if (areaRatio < 0.58) continue;

      const opacity = Number.parseFloat(style.opacity || "1");
      const transparentPointerShield = opacity < 0.03 && style.pointerEvents !== "none";
      if (opacity < 0.03 && !transparentPointerShield) continue;

      let score = 4;
      const role = (el.getAttribute("role") || "").toLowerCase();
      const clsId = `${el.id || ""} ${(el.className || "").toString()}`.toLowerCase();
      const dismissControl = hasDismissControl(el);

      if (el.getAttribute("aria-modal") === "true") score += 3;
      if (role.includes("dialog")) score += 2;
      if (/(overlay|modal|dialog|popup|lightbox|paywall)/i.test(clsId)) score += 2;
      if (areaRatio >= 0.8) score += 2;
      if (zIndex >= 2000) score += 1;
      if (dismissControl) score += 1;
      if (transparentPointerShield) score += 2;

      candidates.push({ el, score });
    }

    candidates.sort((a, b) => b.score - a.score);
    return candidates.slice(0, MAX_OVERLAY_SCAN);
  }

  function hideBackdropLikeElements(elements) {
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    let hidden = 0;

    for (const el of elements) {
      if (shouldSkipForRemoval(el)) continue;
      if (!isElementVisible(el)) continue;

      const style = getComputedStyle(el);
      const position = style.position;
      if (position !== "fixed" && position !== "absolute") continue;

      const z = parseNumber(style.zIndex, 0);
      if (z < OVERLAY_MIN_Z_INDEX) continue;

      const rect = el.getBoundingClientRect();
      if (rect.width < vw * 0.85 || rect.height < vh * 0.85) continue;

      const background = (style.backgroundColor || "").toLowerCase();
      const backdropLike = background.includes("rgba") || background.includes("hsla") || background.includes("rgb(0") || background.includes("rgb(1");
      if (!backdropLike) continue;

      if (recordAndHide(el, "overlay-backdrop")) hidden += 1;
      if (hidden >= 3) break;
    }

    return hidden;
  }

  function removeOverlayAndBackdrop(settings, elements) {
    if (!settings.enableOverlay) return { clicked: 0, hidden: 0 };

    let clicked = 0;
    let hidden = 0;
    const overlays = findOverlayCandidates(elements);

    for (const candidate of overlays) {
      const closeButton = findCloseButton(candidate.el);
      if (closeButton && settings.currentRunMode !== "preview") {
        closeButton.click();
        clicked += 1;
      }
    }

    for (const candidate of overlays) {
      if (recordAndHide(candidate.el, "overlay-main")) hidden += 1;
    }

    hidden += hideBackdropLikeElements(elements);
    return { clicked, hidden };
  }

  function removeInlineAds(settings, vocabSet, hostHints, elements, mainEl) {
    if (!(mainEl instanceof Element)) return 0;

    const viewportArea = getViewportArea();
    const threshold = settings.scoreThreshold;
    const maxRemovals = Math.min(MAX_INLINE_REMOVE, settings.maxNormalRemovals);
    const mainRect = mainEl.getBoundingClientRect();
    const candidates = [];

    for (const el of elements) {
      if (shouldSkipForRemoval(el)) continue;
      if (!isElementVisible(el)) continue;
      if (el.hasAttribute(HIDDEN_ATTR)) continue;
      if (!isWithinMainFlow(el, mainEl)) continue;
      if (isInteractiveChrome(el)) continue;
      if (isNearVideoOrCanvas(el) && !isAdVideoContainer(el)) continue;

      const style = getComputedStyle(el);
      if (style.position === "fixed") continue;

      if (isProtectedContentTree(el, mainEl)) continue;
      const contentGuard = shouldSuppressForContentLikelihood(el, { mainEl, maxScore: 3, allowShortText: true });
      if (contentGuard.suppress) continue;

      const rect = el.getBoundingClientRect();
      const area = getRectArea(rect);
      if (area <= 0 || area >= viewportArea * 0.45) continue;
      if (rect.width < mainRect.width * 0.28) continue;
      if (rect.top < mainRect.top - 32 || rect.bottom > mainRect.bottom + 32) continue;

      let score = 0;
      let reasons = 0;
      let articleBreak = false;
      const textLength = getTextLength(el);

      if (hasInlineIframeHint(el)) {
        score += 2;
        reasons += 1;
      }
      if (settings.signalSize && hasSizeSignal(el, rect)) {
        score += 2;
        reasons += 1;
      }
      if (settings.signalTag && hasTagSignal(el)) {
        score += 1;
        reasons += 1;
      }
      if (settings.signalPosition && hasPositionSignal(el, rect)) {
        score += 1;
        reasons += 1;
      }
      if (hasDirectAdSignature(el)) {
        score += 3;
        reasons += 1;
      }
      if (hasAdHostSignal(el, hostHints)) {
        score += 4;
        reasons += 1;
      }
      if (settings.signalVocab && hasVocabSignal(el, vocabSet)) {
        score += 2;
        reasons += 1;
      }
      if (settings.signalAttribute && hasAttributeSignal(el)) {
        score += 1;
        reasons += 1;
      }
      if (textLength <= INLINE_TEXT_LIMIT) {
        score += 1;
        articleBreak = true;
      }

      const overlapsMainCenter = rect.left <= mainRect.left + mainRect.width * 0.7 && rect.right >= mainRect.left + mainRect.width * 0.3;
      if (overlapsMainCenter) {
        score += 1;
        articleBreak = true;
      }

      if (score >= threshold && reasons >= 2 && articleBreak) {
        candidates.push({ el, score, reasons, area });
      }
    }

    candidates.sort((a, b) => {
      if (b.score !== a.score) return b.score - a.score;
      if (a.area !== b.area) return a.area - b.area;
      return b.reasons - a.reasons;
    });

    let removed = 0;
    const removedTargets = [];
    for (const candidate of candidates) {
      if (removed >= maxRemovals) break;
      const target = getRemovableTarget(candidate.el, mainEl);
      if (!(target instanceof Element)) continue;
      const overlapsExisting = removedTargets.some((done) => done === target || done.contains(target) || target.contains(done));
      if (overlapsExisting) continue;
      if (recordAndHide(target, "inline-article-ad")) {
        removed += 1;
        removedTargets.push(target);
      }
    }

    return removed;
  }


  function removeSideRailAds(settings, vocabSet, hostHints, elements, mainEl) {
    if (!(mainEl instanceof Element)) return 0;

    const mainRect = mainEl.getBoundingClientRect();
    const viewportArea = getViewportArea();
    const vh = window.innerHeight;
    const articleCardWidthThreshold = mainRect.width * 0.72;
    const candidates = [];

    for (const el of elements) {
      if (shouldSkipForRemoval(el)) continue;
      if (!isElementVisible(el)) continue;
      if (el.hasAttribute(HIDDEN_ATTR)) continue;
      if (isWithinMainFlow(el, mainEl)) continue;
      if (isInteractiveChrome(el)) continue;
      if (isNearVideoOrCanvas(el) && !isAdVideoContainer(el)) continue;

      const style = getComputedStyle(el);
      const positionOk = ["fixed", "sticky", "absolute"].includes(style.position) || style.position === "static" || style.position === "relative";
      if (!positionOk) continue;

      if (isProtectedContentTree(el, mainEl)) continue;
      const contentGuard = shouldSuppressForContentLikelihood(el, { mainEl, maxScore: 2, allowShortText: true });
      if (contentGuard.suppress) continue;
      if (el.querySelector(ARTICLE_STRUCTURE_SELECTOR)) continue;
      if (el.closest("article, .entry-content, .post-content, .article-body")) continue;

      const rect = el.getBoundingClientRect();
      const area = getRectArea(rect);
      if (area <= 0 || area >= viewportArea * 0.3) continue;
      if (rect.width < 100 || rect.width > 520) continue;
      if (rect.width >= articleCardWidthThreshold) continue;
      if (rect.height < 180 || rect.height > vh * 0.95) continue;
      if (getTextLength(el) > INLINE_TEXT_LIMIT) continue;
      if (!isSideRailPosition(rect, mainRect)) continue;

      let score = 1;
      let reasons = 0;
      const textLength = getTextLength(el);
      const imgCount = el.querySelectorAll("img").length;
      const linkCount = el.querySelectorAll("a").length;
      const iframeCount = el.querySelectorAll("iframe, ins").length;
      const childCount = Math.max(1, el.childElementCount);
      const mediaCount = imgCount + iframeCount;
      const mediaDominant = mediaCount >= 1 && (linkCount >= 1 || mediaCount >= childCount * 0.5);
      const stackedImages = imgCount >= 2 && rect.height >= rect.width * 1.4;
      const narrowRail = rect.width <= Math.min(420, mainRect.width * 0.42);
      const imageHeavy = mediaCount >= 1 && textLength <= 72;
      const closeButton = findCloseButton(el);
      const collapseControl = findCollapseControl(el);
      const dismissTarget = closeButton?.closest("[style], [class], [id]") || collapseControl?.closest("[style], [class], [id]") || el;
      const hasDismissUi = Boolean(closeButton || collapseControl);
      const bundleInfo = getAbsoluteAdLinkBundleInfo(el, hostHints);

      if (settings.signalTag && (hasTagSignal(el) || Boolean(el.querySelector("iframe, ins, aside, img")))) {
        score += 2;
        reasons += 1;
      }
      if (hasDirectAdSignature(el)) {
        score += 3;
        reasons += 1;
      }
      if (hasAdHostSignal(el, hostHints)) {
        score += 4;
        reasons += 1;
      }
      if (settings.signalVocab && hasVocabSignal(el, vocabSet)) {
        score += 2;
        reasons += 1;
      }
      if (settings.signalAttribute && hasAttributeSignal(el)) {
        score += 1;
        reasons += 1;
      }
      if (settings.signalSize && hasSizeSignal(el, rect)) {
        score += 1;
        reasons += 1;
      }
      if (mediaDominant) {
        score += 2;
      }
      if (stackedImages) {
        score += 1;
      }
      if (settings.enableEdgeClickableHint && hasClickableHint(el).matched) {
        score += 1;
      }
      if (hasDismissUi) {
        score += 2;
        reasons += 1;
      }
      if (bundleInfo.matched) {
        score += bundleInfo.score;
        reasons += 1;
      }
      if (textLength <= INLINE_TEXT_LIMIT) {
        score += 1;
      }
      if (narrowRail) {
        score += 1;
      }
      if (imageHeavy) {
        score += 1;
      }

      if (reasons < 1 && !mediaDominant) continue;
      if (!mediaDominant && !imageHeavy && !hasDismissUi && !bundleInfo.matched) continue;
      if ((mediaDominant && narrowRail && textLength <= INLINE_TEXT_LIMIT) || stackedImages) score += 1;
      if (hasDismissUi && hasDirectAdSignature(el)) score += 2;
      candidates.push({ el, score, area, signature: getRailSignature(el, rect), closeButton, collapseControl, dismissTarget, preferredTarget: bundleInfo.container, hasDismissUi });
    }

    const signatures = candidates.map((candidate) => candidate.signature);
    for (const candidate of candidates) {
      candidate.score += getSideRailSimilarityBonus(candidate.signature, signatures);
    }

    candidates.sort((a, b) => {
      if (b.score !== a.score) return b.score - a.score;
      return b.area - a.area;
    });

    let removed = 0;
    const removedTargets = [];
    for (const candidate of candidates) {
      if (removed >= MAX_SIDE_RAIL_REMOVE) break;
      if (candidate.hasDismissUi && settings.currentRunMode !== "preview") {
        if (candidate.collapseControl) candidate.collapseControl.click();
        else if (candidate.closeButton) candidate.closeButton.click();
      }
      if (candidate.score < (candidate.hasDismissUi ? Math.max(3, settings.scoreThreshold - 1) : Math.max(3, settings.scoreThreshold - 1))) continue;
      const target = getDockedTarget(candidate.preferredTarget || candidate.dismissTarget || candidate.el, mainEl);
      if (!(target instanceof Element)) continue;
      const overlapsExisting = removedTargets.some((done) => done === target || done.contains(target) || target.contains(done));
      if (overlapsExisting) continue;
      if (recordAndHide(target, "side-rail-ad")) {
        removed += 1;
        removedTargets.push(target);
      }
    }

    return removed;
  }

  function removeStructuralEdgeAds(settings, vocabSet, hostHints, elements, mainEl) {
    if (!settings.enableStructEdgeAds) return 0;
    if (!(mainEl instanceof Element)) return 0;

    const mainRect = mainEl.getBoundingClientRect();
    const mainZ = parseZIndex(getComputedStyle(mainEl).zIndex) ?? 0;
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const threshold = settings.edgeStructThreshold;
    const maxRemove = settings.edgeStructMaxRemove;
    const candidates = [];

    for (const el of elements) {
      if (shouldSkipForRemoval(el)) continue;
      if (!isElementVisible(el)) continue;
      if (el.hasAttribute(HIDDEN_ATTR)) continue;
      if (isNearVideoOrCanvas(el) && !isAdVideoContainer(el)) continue;

      const style = getComputedStyle(el);
      if (style.position !== "fixed") continue;

      if (isProtectedContentTree(el, mainEl)) continue;
      const contentGuard = shouldSuppressForContentLikelihood(el, { mainEl, maxScore: 2, allowShortText: true });
      if (contentGuard.suppress) continue;

      const rect = el.getBoundingClientRect();
      const wideEnough = rect.width >= vw * 0.8;
      const shortEnough = rect.height <= vh * settings.edgeMaxHeightRatio;
      const notTooThin = rect.height >= EDGE_MIN_HEIGHT_PX;
      const nearTop = rect.top <= EDGE_MARGIN;
      const nearBottom = rect.bottom >= vh - EDGE_MARGIN;
      if (!wideEnough || !shortEnough || !notTooThin || (!nearTop && !nearBottom)) continue;

      const candZ = parseZIndex(style.zIndex);
      const zHigh = candZ !== null && candZ >= EDGE_MIN_Z_INDEX;
      const weakCandidate = candZ === null || candZ === 0;
      if (!zHigh && !weakCandidate) continue;

      let score = 2;
      let overlapMatched = false;
      let vocabMatched = false;
      const dismissControl = hasDismissControl(el);
      const stackingGuardActive =
        settings.enableEdgeStackingGuard &&
        (hasStackingContextHint(mainEl) || hasStackingContextHint(el));

      if (!stackingGuardActive && candZ !== null && candZ > mainZ) {
        score += 2;
      }

      if (settings.enableEdgeOverlap) {
        const overlapRatio = getOverlapRatio(mainRect, rect);
        if (overlapRatio >= settings.edgeOverlapThreshold) {
          score += 2;
          overlapMatched = true;
        }
      }

      if (settings.enableEdgeClickableHint) {
        const clickableHint = hasClickableHint(el);
        if (clickableHint.matched) {
          score += 1;
        } else if (clickableHint.decorativeOnly) {
          score -= 1;
        }
      }
      if (dismissControl) {
        score += 2;
      }

      if (hasDirectAdSignature(el)) {
        score += 3;
        vocabMatched = true;
      }
      if (hasAdHostSignal(el, hostHints)) {
        score += 4;
        vocabMatched = true;
      }
      if (settings.enableEdgeVocabHint && hasVocabSignal(el, vocabSet)) {
        score += 2;
        vocabMatched = true;
      }

      if (settings.enableEdgeAttributeHint && hasAttributeSignal(el)) {
        score += 1;
      }

      if (stackingGuardActive && !overlapMatched && !vocabMatched) continue;
      if (score >= threshold) {
        candidates.push({ el, score, overlapMatched, vocabMatched });
      }
    }

    candidates.sort((a, b) => {
      if (b.score !== a.score) return b.score - a.score;
      if (b.overlapMatched !== a.overlapMatched) return b.overlapMatched ? -1 : 1;
      if (b.vocabMatched !== a.vocabMatched) return b.vocabMatched ? -1 : 1;
      return 0;
    });

    let removed = 0;
    const removedTargets = [];
    for (const candidate of candidates) {
      if (removed >= maxRemove) break;
      const target = getRemovableTarget(candidate.el, mainEl);
      if (!(target instanceof Element)) continue;
      const overlapsExisting = removedTargets.some((done) => done === target || done.contains(target) || target.contains(done));
      if (overlapsExisting) continue;
      const closeButton = findCloseButton(target);
      if (closeButton && settings.currentRunMode !== "preview") closeButton.click();
      if (recordAndHide(target, "edge-structural-ad")) {
        removed += 1;
        removedTargets.push(target);
      }
    }

    return removed;
  }

  function removeDockedEdgeAds(settings, vocabSet, hostHints, elements, mainEl) {
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const viewportArea = getViewportArea();
    const mainRect = mainEl instanceof Element ? mainEl.getBoundingClientRect() : null;
    const candidates = [];

    for (const el of elements) {
      if (shouldSkipForRemoval(el)) continue;
      if (!isElementVisible(el)) continue;
      if (el.hasAttribute(HIDDEN_ATTR)) continue;
      if (isNearVideoOrCanvas(el) && !isAdVideoContainer(el)) continue;
      if (isProtectedContentTree(el, mainEl)) continue;

      const style = getComputedStyle(el);
      const rect = el.getBoundingClientRect();
      const area = getRectArea(rect);
      if (area < viewportArea * 0.01 || area > viewportArea * 0.35) continue;

      const dock = isDockedEdgePosition(rect);
      if (!dock.matched) continue;
      const directAd = hasDirectAdSignature(el);
      const hostAd = hasAdHostSignal(el, hostHints);
      const absoluteAdFrame = style.position === "absolute" && (directAd || hostAd || el.tagName === "IFRAME");
      if (style.position !== "fixed" && style.position !== "sticky" && !absoluteAdFrame) continue;

      const contentGuard = shouldSuppressForContentLikelihood(el, { mainEl, maxScore: 2, allowShortText: true });
      if (contentGuard.suppress) continue;

      const closeButton = findCloseButton(el);
      const collapseControl = findCollapseControl(el);
      const dismissTarget = closeButton?.closest("[style], [class], [id]") || collapseControl?.closest("[style], [class], [id]") || el;
      const adVideoContainer = isAdVideoContainer(el);
      const bundleInfo = getAbsoluteAdLinkBundleInfo(el, hostHints);
      const clickableHint = hasClickableHint(el);
      const hasMedia = Boolean(el.querySelector("iframe, ins, aside, img, video"));
      const hasVideo = Boolean(el.querySelector("video"));
      const z = parseNumber(style.zIndex, 0);
      const transformActive = style.transform && style.transform !== "none";
      const overlapRatio = mainRect ? getOverlapRatio(mainRect, rect) : 0;
      const shortText = getTextLength(el) <= Math.max(INLINE_TEXT_LIMIT, 220);

      let score = 1;
      let signals = 0;
      const hasDismissUi = Boolean(closeButton || collapseControl);
      if (dock.bottomTopBand || dock.sideBand) score += 1;
      if (dock.cornerFloat) score += 2;
      if (closeButton) {
        score += 3;
        signals += 1;
      }
      if (collapseControl) {
        score += 3;
        signals += 1;
      }
      if (directAd) {
        score += 3;
        signals += 1;
      }
      if (hostAd) {
        score += 4;
        signals += 1;
      }
      if (absoluteAdFrame) {
        score += 2;
        signals += 1;
      }
      if (settings.enableEdgeVocabHint && hasVocabSignal(el, vocabSet)) {
        score += 2;
        signals += 1;
      }
      if (settings.enableEdgeAttributeHint && hasAttributeSignal(el)) {
        score += 1;
        signals += 1;
      }
      if (clickableHint.matched) {
        score += 1;
        signals += 1;
      }
      if (hasMedia) {
        score += 1;
        signals += 1;
      }
      if (bundleInfo.matched) {
        score += bundleInfo.score;
        signals += 1;
      }
      if (hasVideo && (hasDirectAdSignature(el) || hasDismissUi || z >= 999 || adVideoContainer)) {
        score += 3;
        signals += 1;
      }
      if (transformActive) score += 1;
      if (shortText) score += 1;
      if (z >= EDGE_MIN_Z_INDEX) score += 1;
      if (overlapRatio >= 0.08) score += 1;
      if (rect.width >= vw * 0.4 && rect.height <= vh * 0.28) score += 1;
      if (rect.height >= vh * 0.35 && rect.width <= vw * 0.3) score += 1;
      if (dock.nearBottom && rect.height <= vh * 0.3) score += 1;

      if (!hasDismissUi && !dock.cornerFloat && signals < 2) continue;
      if (hasDismissUi && score >= 4) {
        candidates.push({ el, score, closeButton, collapseControl, dismissTarget, area });
        continue;
      }
      if (adVideoContainer && score >= 4) {
        candidates.push({ el, score, closeButton, collapseControl, dismissTarget, area });
        continue;
      }
      if (dock.cornerFloat && hasMedia && clickableHint.matched && score >= 4) {
        candidates.push({ el, score, closeButton, collapseControl, dismissTarget, preferredTarget: bundleInfo.container, area });
        continue;
      }
      if (bundleInfo.matched && score >= 4) {
        candidates.push({ el, score, closeButton, collapseControl, dismissTarget, preferredTarget: bundleInfo.container, area });
        continue;
      }
      if (score >= 5) {
        candidates.push({ el, score, closeButton, collapseControl, dismissTarget, preferredTarget: bundleInfo.container, area });
      }
    }

    candidates.sort((a, b) => {
      if (b.score !== a.score) return b.score - a.score;
      return b.area - a.area;
    });

    let removed = 0;
    const removedTargets = [];
    for (const candidate of candidates) {
      if (removed >= 3) break;
      if (settings.currentRunMode !== "preview") {
        if (candidate.collapseControl) candidate.collapseControl.click();
        else if (candidate.closeButton) candidate.closeButton.click();
      }

      const target = getDockedTarget(candidate.preferredTarget || candidate.dismissTarget || candidate.el, mainEl);
      if (!(target instanceof Element)) continue;
      const overlapsExisting = removedTargets.some((done) => done === target || done.contains(target) || target.contains(done));
      if (overlapsExisting) continue;
      if (recordAndHide(target, "edge-docked-ad")) {
        removed += 1;
        removedTargets.push(target);
      }
    }

    return removed;
  }

  function removeEdgeBanners(settings, vocabSet, hostHints, elements, mainEl) {
    if (!settings.enableEdgeBanner) return 0;

    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const mainRect = mainEl instanceof Element ? mainEl.getBoundingClientRect() : null;
    const candidates = [];

    for (const el of elements) {
      if (shouldSkipForRemoval(el)) continue;
      if (!isElementVisible(el)) continue;
      if (el.hasAttribute(HIDDEN_ATTR)) continue;

      const style = getComputedStyle(el);
      if (style.position !== "fixed") continue;

      const z = parseNumber(style.zIndex, 0);
      if (z < EDGE_MIN_Z_INDEX) continue;

      const rect = el.getBoundingClientRect();
      const wideEnough = rect.width >= vw * 0.78;
      const shortEnough = rect.height <= vh * settings.edgeMaxHeightRatio;
      const notTooThin = rect.height >= EDGE_MIN_HEIGHT_PX;
      const nearTop = rect.top <= EDGE_MARGIN;
      const nearBottom = rect.bottom >= vh - EDGE_MARGIN;
      if (!wideEnough || !shortEnough || !notTooThin || (!nearTop && !nearBottom)) continue;

      let score = 2;
      let adSignals = 0;
      const dismissControl = hasDismissControl(el);

      if (dismissControl) {
        score += 2;
        adSignals += 1;
      }
      if (hasDirectAdSignature(el)) {
        score += 3;
        adSignals += 1;
      }
      if (hasAdHostSignal(el, hostHints)) {
        score += 4;
        adSignals += 1;
      }
      if (settings.enableEdgeVocabHint && hasVocabSignal(el, vocabSet)) {
        score += 2;
        adSignals += 1;
      }
      if (settings.enableEdgeAttributeHint && hasAttributeSignal(el)) {
        score += 1;
        adSignals += 1;
      }
      if (settings.enableEdgeClickableHint && hasClickableHint(el).matched) {
        score += 1;
        adSignals += 1;
      }
      if (mainRect && getOverlapRatio(mainRect, rect) >= settings.edgeOverlapThreshold) {
        score += 1;
      }
      if (getTextLength(el) <= INLINE_TEXT_LIMIT) {
        score += 1;
      }

      if (adSignals < 1) continue;
      if (score >= Math.max(4, settings.edgeStructThreshold - 1)) {
        candidates.push({ el, score });
      }
    }

    candidates.sort((a, b) => b.score - a.score);

    let removed = 0;
    for (const candidate of candidates) {
      const closeButton = findCloseButton(candidate.el);
      if (closeButton && settings.currentRunMode !== "preview") closeButton.click();
      if (recordAndHide(candidate.el, "edge-banner-ad")) {
        removed += 1;
      }
      if (removed >= 2) break;
    }

    return removed;
  }

  async function loadPackagedVocab() {
    if (cachedPackagedVocab) return cachedPackagedVocab;

    try {
      const url = chrome.runtime.getURL("vocab/ad_hint_words.json");
      const res = await fetch(url);
      const json = await res.json();
      cachedPackagedVocab = Array.isArray(json?.words) ? json.words : [];
      return cachedPackagedVocab;
    } catch (_error) {
      cachedPackagedVocab = [];
      return cachedPackagedVocab;
    }
  }

  async function loadRuntimeConfig() {
    const fallback = {
      ...DEFAULT_SETTINGS,
      customHintWords: null,
      customHintMeta: null,
      siteRules: {}
    };

    let data = fallback;
    try {
      const storage = await chrome.storage.local.get(fallback);
      data = { ...fallback, ...storage };
    } catch (_error) {
      data = fallback;
    }

    const packaged = await loadPackagedVocab();
    const userWords = Array.isArray(data.customHintWords) ? data.customHintWords : [];
    const userHostHints = userWords.map((w) => normalizeHostHint(w)).filter((w) => isHostLikeHint(w));
    const vocabWords = userWords.filter((w) => !isHostLikeHint(w));
    const vocab = new Set([...CORE_VOCAB, ...packaged, ...vocabWords].map((w) => (w || "").toLowerCase()).filter(Boolean));
    const hostHints = new Set([...CORE_HOST_HINTS, ...userHostHints].map((w) => normalizeHostHint(w)).filter(Boolean));

    return {
      settings: {
        ...DEFAULT_SETTINGS,
        ...data,
        scoreThreshold: Math.max(2, Math.min(12, parseNumber(data.scoreThreshold, DEFAULT_SETTINGS.scoreThreshold))),
        maxNormalRemovals: Math.max(1, Math.min(30, parseNumber(data.maxNormalRemovals, DEFAULT_SETTINGS.maxNormalRemovals))),
        edgeOverlapThreshold: Math.max(0, Math.min(1, parseNumber(data.edgeOverlapThreshold, DEFAULT_SETTINGS.edgeOverlapThreshold))),
        edgeStructThreshold: Math.max(3, Math.min(12, parseNumber(data.edgeStructThreshold, DEFAULT_SETTINGS.edgeStructThreshold))),
        edgeStructMaxRemove: Math.max(1, Math.min(6, parseNumber(data.edgeStructMaxRemove, DEFAULT_SETTINGS.edgeStructMaxRemove))),
        edgeMaxHeightRatio: Math.max(0.1, Math.min(0.6, parseNumber(data.edgeMaxHeightRatio, DEFAULT_SETTINGS.edgeMaxHeightRatio))),
        defaultRunMode: normalizeRunMode(data.defaultRunMode),
        previewProtectOutlines: data.previewProtectOutlines !== false,
        learnFromUndo: data.learnFromUndo !== false,
        siteRules: data.siteRules && typeof data.siteRules === "object" ? data.siteRules : {}
      },
      vocab,
      hostHints
    };
  }

  async function dismissOnce(runMode = null) {
    const { settings, vocab, hostHints } = await loadRuntimeConfig();
    settings.currentRunMode = normalizeRunMode(runMode || settings.defaultRunMode);
    const hostRules = getSavedSiteRules(settings);
    if (hostRules.mode === "disabled") {
      return { ok: false, detail: { skipped: "site-disabled" } };
    }
    if (!runMode && hostRules.mode === "strong") {
      settings.currentRunMode = "strong";
    }
    // Preview badges are extension-owned DOM. Remove them before taking the
    // candidate snapshot so neither a badge nor its subtree becomes a target.
    clearPreviewArtifacts();
    const collection = collectAllElements();
    const elements = collection.elements;
    const mainEl = findMainContent();

    beginBatch(`dismiss-${settings.currentRunMode}`);
    activeBatch.settings = settings;
    const overlayResult = removeOverlayAndBackdrop(settings, elements);
    const overlayChanged = overlayResult.clicked > 0 || overlayResult.hidden > 0;
    const scrollUnlocked = settings.currentRunMode !== "preview" && overlayChanged ? clearScrollLock() : 0;
    // Keep the narrow Google forms together between overlay recovery and the
    // general heuristics. Hidden/detached/neutralized nodes are excluded below.
    const googleRootResult = window.top === window ? removeGoogleHtmlRootAds(elements) : { candidates: 0, removed: 0 };
    const googleAnchorResult = window.top === window ? removeGoogleShoppingAnchors(elements) : { candidates: 0, removed: 0 };
    const googleChipResult = window.top === window ? removeGoogleAnnotationChips(elements) : { candidates: 0, removed: 0 };
    const googleLinkResult = window.top === window ? neutralizeGoogleAnnotationLinks(elements) : { candidates: 0, neutralized: 0 };
    const inlineRemoved = removeInlineAds(settings, vocab, hostHints, elements, mainEl);
    const sideRailRemoved = removeSideRailAds(settings, vocab, hostHints, elements, mainEl);
    const structEdgeRemoved = removeStructuralEdgeAds(settings, vocab, hostHints, elements, mainEl);
    const dockedEdgeRemoved = removeDockedEdgeAds(settings, vocab, hostHints, elements, mainEl);
    const edgeRemoved = removeEdgeBanners(settings, vocab, hostHints, elements, mainEl);
    const previewed = activeBatch?.previewed.length || 0;
    const skipped = activeBatch?.skipped.length || 0;
    const skippedDetails = settings.debugLogs
      ? (activeBatch?.skipped || []).slice(0, 20).map((item) => ({
          reason: item.reason,
          decision: item.classification?.decision,
          protectScore: item.classification?.protectScore,
          riskScore: item.classification?.riskScore,
          protectReasons: item.classification?.protectReasons,
          riskReasons: item.classification?.riskReasons,
          selector: getSelectorHint(item.el)
        }))
      : [];
    const changed = finalizeBatch();

    log(settings.debugLogs, {
      mode: settings.currentRunMode,
      overlayClicked: overlayResult.clicked,
      overlayHidden: overlayResult.hidden,
      scrollUnlocked,
      inlineRemoved,
      sideRailRemoved,
      structEdgeRemoved,
      dockedEdgeRemoved,
      edgeRemoved,
      collected: collection.counts,
      googleRootAds: googleRootResult,
      googleAnchors: googleAnchorResult,
      googleChips: googleChipResult,
      googleLinks: googleLinkResult,
      previewed,
      skipped,
      skippedDetails,
      batchCount: actionHistory.length
    });

    return {
      ok: changed || overlayResult.clicked > 0 || previewed > 0,
      detail: {
        mode: settings.currentRunMode,
        overlayClicked: overlayResult.clicked,
        overlayHidden: overlayResult.hidden,
        scrollUnlocked,
        inlineRemoved,
        sideRailRemoved,
        structEdgeRemoved,
        dockedEdgeRemoved,
        edgeRemoved,
        collected: collection.counts,
        googleRootAds: googleRootResult,
        googleAnchors: googleAnchorResult,
        googleChips: googleChipResult,
        googleLinks: googleLinkResult,
        previewed,
        skipped
      }
    };
  }

  async function runDismissSerial(runMode = null) {
    if (commandBusy) return { ok: false, detail: "dismiss-busy" };
    commandBusy = true;
    try {
      return await dismissOnce(runMode);
    } finally {
      commandBusy = false;
    }
  }

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (!msg || typeof msg.type !== "string") return undefined;

    if (msg.type === "OK_DISMISS") {
      if (window.top === window) {
        broadcastToChildFrames({ type: "OK_DISMISS_FRAME", mode: msg.mode });
      }
      runDismissSerial(msg.mode)
        .then((result) => sendResponse(result))
        .catch((_error) => sendResponse({ ok: false, detail: "dismiss-error" }));
      return true;
    }

    if (msg.type === "OK_CLEAR_PREVIEW") {
      if (window.top === window) {
        broadcastToChildFrames({ type: "OK_CLEAR_PREVIEW_FRAME" });
      }
      clearPreviewArtifacts();
      sendResponse({ ok: true, detail: "preview-cleared" });
      return false;
    }

    if (msg.type === "OK_UNDO") {
      if (commandBusy) {
        sendResponse({ ok: false, detail: "dismiss-busy" });
        return false;
      }
      sendResponse(undoLast());
      return false;
    }

    return undefined;
  });

  window.addEventListener("message", (event) => {
    const data = event?.data;
    if (!data || data.__overlayKillerFrameCommand !== true) return;
    if (data.type === "OK_DISMISS_FRAME") {
      runDismissSerial(data.mode).catch(() => {});
      return;
    }
    if (data.type === "OK_CLEAR_PREVIEW_FRAME") {
      clearPreviewArtifacts();
    }
  });

  setupShadowTracking();
})();







