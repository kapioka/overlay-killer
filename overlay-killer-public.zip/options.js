const DEFAULT_SETTINGS = {
  signalSize: true,
  signalTag: true,
  signalPosition: false,
  signalVocab: true,
  signalAttribute: true,
  scoreThreshold: 4,
  maxNormalRemovals: 6,
  enableEdgeBanner: true,
  enableStructEdgeAds: true,
  enableEdgeOverlap: true,
  edgeOverlapThreshold: 0.15,
  enableEdgeClickableHint: true,
  enableEdgeStackingGuard: true,
  enableEdgeVocabHint: true,
  enableEdgeAttributeHint: true,
  edgeStructThreshold: 5,
  edgeStructMaxRemove: 2,
  edgeMaxHeightRatio: 0.35,
  enableOverlay: true,
  defaultRunMode: "standard",
  previewProtectOutlines: true,
  learnFromUndo: true,
  debugLogs: false,
  customHintWords: null,
  customHintMeta: null,
  vocabItems: null,
  vocabSources: null,
  vocabUiState: null,
  siteRules: null
};

const CHECKBOX_IDS = [
  "signalSize",
  "signalTag",
  "signalPosition",
  "signalVocab",
  "signalAttribute",
  "enableEdgeBanner",
  "enableStructEdgeAds",
  "enableEdgeOverlap",
  "enableEdgeClickableHint",
  "enableEdgeStackingGuard",
  "enableEdgeVocabHint",
  "enableEdgeAttributeHint",
  "enableOverlay",
  "previewProtectOutlines",
  "learnFromUndo",
  "debugLogs"
];

const NUMBER_IDS = [
  "scoreThreshold",
  "maxNormalRemovals",
  "edgeOverlapThreshold",
  "edgeStructThreshold",
  "edgeStructMaxRemove",
  "edgeMaxHeightRatio"
];

const TXT_TOP_N = 2000;
const TXT_MIN_LEN = 3;
const TXT_MAX_LEN = 30;
const PAGE_SIZE = 200;

const CORE_WORDS = [
  "ad",
  "ads",
  "advert",
  "advertisement",
  "advertising",
  "adframe",
  "adservice",
  "adsbygoogle",
  "adsense",
  "adslot",
  "sponsor",
  "sponsored",
  "promo",
  "promoted",
  "doubleclick",
  "taboola",
  "outbrain"
];

const STOPWORDS = new Set([
  "the", "and", "for", "with", "from", "this", "that", "news", "header", "footer", "main", "content",
  "section", "left", "right", "center", "page", "body", "html", "container", "wrapper", "image", "video",
  "button", "title", "small", "large", "menu", "widget", "article", "media", "player", "social",
  "recommend", "timeline", "cookie", "cookies", "google", "amazon", "shopify", "frontend", "assets",
  "script", "scripts", "loader", "static", "service", "services", "default", "global", "common", "core",
  "data", "base", "build", "dist", "module", "modules", "public", "site", "web"
]);

const EXACT_DENY = new Set([
  "analytics", "analytic", "analyticsjs", "track", "tracker", "tracking", "pixel", "pixels", "beacon",
  "metric", "metrics", "telemetry", "stat", "stats", "counter", "count", "pageview", "pageviews",
  "visit", "visitor", "visitors", "event", "events", "click", "logger", "log", "monitor", "gtm",
  "gtag", "datalayer", "tagmanager", "sentry", "newrelic", "rollbar", "matomo", "plausible",
  "chartbeat", "comscore", "img", "images", "1px", "1x1", "2x2"
]);

const ALLOW_PATTERNS = [
  /^ad$/,
  /^ads$/,
  /(^|[-_])ad(s)?([_-]|$)/,
  /^ad(slot|unit|frame|iframe|sense|service|server|manager|banner|popup|choices|block|blocking|sidebar|top|bottom|left|right|rotator|layer|provider|shield|script|scroll|position|placements?)$/,
  /^ads(bygoogle|ense|lot|image|images|img|server|banner|wrapper|manager|delivery|plugin|native)?$/,
  /advert/,
  /sponsor/,
  /sponsored/,
  /promo/,
  /promoted/,
  /nativead/,
  /banner/,
  /popup/,
  /popunder/,
  /stickyad/,
  /pagead/,
  /doubleclick/,
  /taboola/,
  /outbrain/,
  /prebid/,
  /criteo/,
  /adnxs/,
  /pubmatic/,
  /rubicon/,
  /videoad/,
  /preroll/,
  /midroll/,
  /instream/,
  /vast/,
  /amp.*ad/,
  /affiliateads?/
];

const DENY_PATTERNS = [
  /analytic/,
  /track/,
  /pixel/,
  /beacon/,
  /telemetry/,
  /metric/,
  /stat(?!ic|us)/,
  /counter/,
  /pageview/,
  /visitor/,
  /session/,
  /cookie/,
  /gtm/,
  /gtag/,
  /datalayer/,
  /tagmanager/,
  /logger/,
  /monitor/,
  /click/,
  /sentry/,
  /newrelic/,
  /rollbar/,
  /matomo/,
  /plausible/,
  /chartbeat/,
  /comscore/,
  /social/,
  /timeline/,
  /recommend/
];

const CATEGORY_DEFS = [
  {
    id: "ad_core",
    label: "ad_core",
    patterns: [/^ad$/, /^ads$/, /advert/, /adsense/, /adsbygoogle/, /ad(slot|frame|server|service|unit|banner|manager)/, /adtech/, /adnet/, /pagead/]
  },
  {
    id: "sponsor_promo",
    label: "sponsor_promo",
    patterns: [/sponsor/, /promo/, /promoted/, /nativead/, /brandcontent/, /affiliateads?/]
  },
  {
    id: "network_vendor",
    label: "network_vendor",
    patterns: [/doubleclick/, /taboola/, /outbrain/, /criteo/, /adnxs/, /pubmatic/, /rubicon/, /prebid/]
  },
  {
    id: "video_media",
    label: "video_media",
    patterns: [/preroll/, /midroll/, /videoad/, /instream/, /vast/, /playerad/]
  },
  {
    id: "ui_blocker",
    label: "ui_blocker",
    patterns: [/popup/, /popunder/, /stickyad/, /banner/, /adchoices/]
  },
  {
    id: "misc",
    label: "misc",
    patterns: []
  }
];

const CATEGORY_IDS = CATEGORY_DEFS.map((c) => c.id);
const TOKEN_RE = /[a-z0-9][a-z0-9_-]{1,}/g;
const ATTR_VALUE_RE = /\[([a-zA-Z0-9_-]+)(?:[*^$|~]?=\"?([^\]\"']+)\"?)?\]/g;
const HOST_HINT_RE = /^(?:https?:\/\/)?(?:[a-z0-9-]+\.)+[a-z]{2,}(?:\/[a-z0-9._~!$&\'()*+,;=:@%-]*)?$/i;


const statusEl = document.getElementById("status");
const vocabCountEl = document.getElementById("vocabCount");
const vocabUpdatedAtEl = document.getElementById("vocabUpdatedAt");
const vocabModeEl = document.getElementById("vocabMode");
const vocabPreviewEl = document.getElementById("vocabPreview");
const categoryListEl = document.getElementById("categoryList");
const vocabSearchEl = document.getElementById("vocabSearch");
const hideMiscEl = document.getElementById("hideMisc");

let statusTimer = null;
let packagedVocabWords = [];
let packagedVocabMeta = null;
let localState = {
  vocabItems: [],
  vocabSources: [],
  vocabUiState: { expandedCategories: [], search: "", hideMisc: false },
  customHintMeta: null
};

const pageByCategory = {};

function showStatus(text, isError = false) {
  if (!statusEl) return;
  statusEl.textContent = text;
  statusEl.classList.toggle("error", isError);
  clearTimeout(statusTimer);
  statusTimer = setTimeout(() => {
    statusEl.textContent = "";
    statusEl.classList.remove("error");
  }, 2200);
}

function clamp(value, min, max, fallback) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, Math.round(n)));
}

function clampFloat(value, min, max, fallback, digits = 2) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  const clamped = Math.min(max, Math.max(min, n));
  return Number(clamped.toFixed(digits));
}

function normalizeHostHint(raw) {
  const value = (raw || "").trim().toLowerCase();
  if (!value) return null;
  if (!HOST_HINT_RE.test(value)) return null;
  const withoutScheme = value.replace(/^https?:\/\//, "");
  const hostAndPath = withoutScheme.replace(/^[|]+/, "").replace(/[\^*]+$/g, "");
  return hostAndPath.length >= 4 && hostAndPath.length <= 120 ? hostAndPath : null;
}

function shouldKeepHostHint(word) {
  return Boolean(normalizeHostHint(word));
}

function normalizeWords(words) {
  const set = new Set();
  for (const raw of words || []) {
    if (typeof raw !== "string") continue;
    const w = raw.trim().toLowerCase();
    if (!w) continue;
    const hostHint = normalizeHostHint(w);
    if (hostHint) {
      set.add(hostHint);
      continue;
    }
    if (w.length < 2 || w.length > 40) continue;
    if (!shouldKeepWord(w)) continue;
    set.add(w);
  }
  return Array.from(set).sort();
}

function makeSourceId() {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

function shouldKeepWord(word) {
  if (!word) return false;
  if (CORE_WORDS.includes(word)) return true;
  if (STOPWORDS.has(word) || EXACT_DENY.has(word)) return false;
  if (ALLOW_PATTERNS.some((pattern) => pattern.test(word))) return true;
  if (DENY_PATTERNS.some((pattern) => pattern.test(word))) return false;
  return false;
}

function classifyWord(word) {
  for (const cat of CATEGORY_DEFS) {
    if (cat.id === "misc") continue;
    if (cat.patterns.some((p) => p.test(word))) {
      return cat.id;
    }
  }
  return "misc";
}
function sanitizeSourceIds(ids) {
  if (!Array.isArray(ids)) return [];
  return Array.from(new Set(ids.filter((v) => typeof v === "string" && v.trim())));
}

function sanitizeVocabItem(raw) {
  const word = typeof raw?.word === "string" ? raw.word.trim().toLowerCase() : "";
  if (!word) return null;
  const category = CATEGORY_IDS.includes(raw?.category) ? raw.category : classifyWord(word);
  return {
    word,
    enabled: Boolean(raw?.enabled),
    category,
    sourceIds: sanitizeSourceIds(raw?.sourceIds)
  };
}

function ensureUiState(rawUiState) {
  const expanded = Array.isArray(rawUiState?.expandedCategories)
    ? rawUiState.expandedCategories.filter((c) => CATEGORY_IDS.includes(c))
    : [];
  const search = typeof rawUiState?.search === "string" ? rawUiState.search : "";
  const hideMisc = Boolean(rawUiState?.hideMisc);
  return { expandedCategories: Array.from(new Set(expanded)), search, hideMisc };
}

function mergeWordsToVocabItems(existingItems, words, sourceId) {
  const map = new Map(existingItems.map((item) => [item.word, { ...item, sourceIds: [...item.sourceIds] }]));
  for (const word of words) {
    const found = map.get(word);
    if (found) {
      if (!found.sourceIds.includes(sourceId)) {
        found.sourceIds.push(sourceId);
      }
      continue;
    }

    map.set(word, {
      word,
      enabled: true,
      category: classifyWord(word),
      sourceIds: [sourceId]
    });
  }

  return Array.from(map.values()).sort((a, b) => a.word.localeCompare(b.word));
}

function enabledWordsFromItems(items) {
  return items.filter((item) => item.enabled).map((item) => item.word).sort((a, b) => a.localeCompare(b));
}

function normalizeTxtToken(raw) {
  const token = (raw || "").trim().toLowerCase();
  if (!token) return null;
  const hostHint = normalizeHostHint(token);
  if (hostHint) return hostHint;
  if (token.length < TXT_MIN_LEN || token.length > TXT_MAX_LEN) return null;
  if (STOPWORDS.has(token)) return null;
  if (/^\d+$/.test(token)) return null;
  return token;
}

function splitNetworkParts(line) {
  let text = line;
  if (text.startsWith("@@")) text = text.slice(2);
  text = text.split("$", 1)[0];

  return text
    .replaceAll("||", " ")
    .replaceAll("|", " ")
    .replaceAll("^", " ")
    .replaceAll("*", " ")
    .replaceAll("=", " ")
    .replaceAll("?", " ")
    .replaceAll("&", " ")
    .replaceAll(":", " ")
    .replaceAll("/", " ")
    .replaceAll(".", " ")
    .replaceAll("_", " ")
    .replaceAll("-", " ");
}

function extractCosmeticTokens(line) {
  if (line.includes("#@#")) return [];
  if (!line.includes("##")) return [];

  const selector = line.split("##", 2)[1] || "";
  const tokens = [];
  const selectorTokens = selector.toLowerCase().match(TOKEN_RE) || [];
  tokens.push(...selectorTokens);

  for (const match of selector.matchAll(ATTR_VALUE_RE)) {
    const attr = (match[1] || "").toLowerCase();
    const value = (match[2] || "").toLowerCase();
    if (attr) tokens.push(attr);
    if (value) tokens.push(...(value.match(TOKEN_RE) || []));
  }

  return tokens;
}

function extractNetworkTokens(line) {
  const text = splitNetworkParts(line.toLowerCase());
  return text.match(TOKEN_RE) || [];
}


function extractNetworkHostHints(line) {
  const matches = line.toLowerCase().match(/(?:https?:\/\/)?(?:[a-z0-9-]+\.)+[a-z]{2,}(?:\/[a-z0-9._~!$&'()*+,;=:@%\/-]*)?/g) || [];
  return matches.map((value) => normalizeHostHint(value)).filter(Boolean);
}

function iterFilterLines(text) {
  const lines = [];
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line) continue;
    if (line.startsWith("!")) continue;
    if (line.startsWith("[Adblock")) continue;
    if (line.startsWith("#") && !line.startsWith("##") && !line.startsWith("#@#")) continue;
    lines.push(line);
  }
  return lines;
}

function parseTxtAndExtractWords(text) {
  if (!text || !text.trim()) throw new Error("ファイルが空です");

  const freq = new Map();
  const lines = iterFilterLines(text);
  for (const line of lines) {
    const rawTokens = line.includes("##") || line.includes("#@#")
      ? extractCosmeticTokens(line)
      : [...extractNetworkTokens(line), ...extractNetworkHostHints(line)];

    for (const raw of rawTokens) {
      const token = normalizeTxtToken(raw);
      if (!token) continue;
      freq.set(token, (freq.get(token) || 0) + 1);
    }
  }

  const sorted = Array.from(freq.entries()).sort((a, b) => {
    if (b[1] !== a[1]) return b[1] - a[1];
    return a[0].localeCompare(b[0]);
  });

  const topWords = sorted.slice(0, TXT_TOP_N).map((v) => v[0]);
  const finalWords = normalizeWords([...topWords, ...CORE_WORDS]);
  if (finalWords.length === 0) throw new Error("語彙を抽出できませんでした");

  return {
    words: finalWords,
    preview: finalWords.slice(0, 12),
    meta: {
      generated_at: new Date().toISOString(),
      imported_at: new Date().toISOString(),
      source: "manual-text-file",
      mode: "txt-extracted",
      topN: TXT_TOP_N,
      minLen: TXT_MIN_LEN,
      maxLen: TXT_MAX_LEN,
      grouping: "semantic-category"
    }
  };
}

function parseVocabJson(jsonText) {
  const parsed = JSON.parse(jsonText);
  if (!parsed || !Array.isArray(parsed.words)) throw new Error("words 配列がありません");

  const words = normalizeWords(parsed.words);
  if (words.length === 0) throw new Error("words が空です");

  return {
    words,
    preview: words.slice(0, 12),
    meta: {
      generated_at: parsed?.meta?.generated_at || new Date().toISOString(),
      imported_at: new Date().toISOString(),
      source: parsed?.meta?.sources || parsed?.meta?.source || "manual-json",
      mode: "json-imported",
      topN: parsed?.meta?.topN ?? null,
      minLen: parsed?.meta?.minLen ?? null,
      maxLen: parsed?.meta?.maxLen ?? null,
      grouping: "semantic-category"
    }
  };
}

function looksLikeJson(text) {
  const t = (text || "").trim();
  return t.startsWith("{") || t.startsWith("[");
}

function parseImportedFile(fileText, fileName) {
  const lower = (fileName || "").toLowerCase();
  const trimmed = (fileText || "").trim();
  if (!trimmed) throw new Error("ファイルが空です");

  if (lower.endsWith(".json") || looksLikeJson(trimmed)) {
    return parseVocabJson(trimmed);
  }
  return parseTxtAndExtractWords(trimmed);
}

async function loadPackagedVocab() {
  try {
    const url = chrome.runtime.getURL("vocab/ad_hint_words.json");
    const res = await fetch(url);
    const json = await res.json();
    packagedVocabWords = normalizeWords(Array.isArray(json?.words) ? json.words : []);
    packagedVocabMeta = json?.meta || null;
  } catch (_error) {
    packagedVocabWords = [];
    packagedVocabMeta = null;
  }
}

function getInputValues() {
  const data = {};
  for (const id of CHECKBOX_IDS) {
    const el = document.getElementById(id);
    if (el) data[id] = Boolean(el.checked);
  }

  const thresholdEl = document.getElementById("scoreThreshold");
  const maxEl = document.getElementById("maxNormalRemovals");
  const edgeOverlapThresholdEl = document.getElementById("edgeOverlapThreshold");
  const edgeStructThresholdEl = document.getElementById("edgeStructThreshold");
  const edgeStructMaxRemoveEl = document.getElementById("edgeStructMaxRemove");
  const edgeMaxHeightRatioEl = document.getElementById("edgeMaxHeightRatio");
  const defaultRunModeEl = document.getElementById("defaultRunMode");

  data.scoreThreshold = clamp(thresholdEl?.value, 2, 12, DEFAULT_SETTINGS.scoreThreshold);
  data.maxNormalRemovals = clamp(maxEl?.value, 1, 30, DEFAULT_SETTINGS.maxNormalRemovals);
  data.edgeOverlapThreshold = clampFloat(edgeOverlapThresholdEl?.value, 0, 1, DEFAULT_SETTINGS.edgeOverlapThreshold, 2);
  data.edgeStructThreshold = clamp(edgeStructThresholdEl?.value, 3, 12, DEFAULT_SETTINGS.edgeStructThreshold);
  data.edgeStructMaxRemove = clamp(edgeStructMaxRemoveEl?.value, 1, 6, DEFAULT_SETTINGS.edgeStructMaxRemove);
  data.edgeMaxHeightRatio = clampFloat(edgeMaxHeightRatioEl?.value, 0.1, 0.6, DEFAULT_SETTINGS.edgeMaxHeightRatio, 2);
  data.defaultRunMode = ["standard", "strong", "preview"].includes(defaultRunModeEl?.value)
    ? defaultRunModeEl.value
    : DEFAULT_SETTINGS.defaultRunMode;
  return data;
}

async function saveInputValues() {
  await chrome.storage.local.set(getInputValues());
  showStatus("保存しました");
}

function applyValuesToInputs(data) {
  for (const id of CHECKBOX_IDS) {
    const el = document.getElementById(id);
    if (el) el.checked = Boolean(data[id]);
  }

  const thresholdEl = document.getElementById("scoreThreshold");
  const maxEl = document.getElementById("maxNormalRemovals");
  const edgeOverlapThresholdEl = document.getElementById("edgeOverlapThreshold");
  const edgeStructThresholdEl = document.getElementById("edgeStructThreshold");
  const edgeStructMaxRemoveEl = document.getElementById("edgeStructMaxRemove");
  const edgeMaxHeightRatioEl = document.getElementById("edgeMaxHeightRatio");
  const defaultRunModeEl = document.getElementById("defaultRunMode");

  if (thresholdEl) thresholdEl.value = String(clamp(data.scoreThreshold, 2, 12, DEFAULT_SETTINGS.scoreThreshold));
  if (maxEl) maxEl.value = String(clamp(data.maxNormalRemovals, 1, 30, DEFAULT_SETTINGS.maxNormalRemovals));
  if (edgeOverlapThresholdEl) {
    edgeOverlapThresholdEl.value = String(clampFloat(data.edgeOverlapThreshold, 0, 1, DEFAULT_SETTINGS.edgeOverlapThreshold, 2));
  }
  if (edgeStructThresholdEl) {
    edgeStructThresholdEl.value = String(clamp(data.edgeStructThreshold, 3, 12, DEFAULT_SETTINGS.edgeStructThreshold));
  }
  if (edgeStructMaxRemoveEl) {
    edgeStructMaxRemoveEl.value = String(clamp(data.edgeStructMaxRemove, 1, 6, DEFAULT_SETTINGS.edgeStructMaxRemove));
  }
  if (edgeMaxHeightRatioEl) {
    edgeMaxHeightRatioEl.value = String(clampFloat(data.edgeMaxHeightRatio, 0.1, 0.6, DEFAULT_SETTINGS.edgeMaxHeightRatio, 2));
  }
  if (defaultRunModeEl) {
    defaultRunModeEl.value = ["standard", "strong", "preview"].includes(data.defaultRunMode)
      ? data.defaultRunMode
      : DEFAULT_SETTINGS.defaultRunMode;
  }
}

function getWordsInCategory(categoryId, searchText, hideMisc) {
  let list = localState.vocabItems.filter((item) => item.category === categoryId);
  if (hideMisc && categoryId === "misc") return [];

  const query = (searchText || "").trim().toLowerCase();
  if (!query) return list;
  return list.filter((item) => item.word.includes(query));
}

function getCategoryStats(categoryId, searchText, hideMisc) {
  const words = getWordsInCategory(categoryId, searchText, hideMisc);
  const enabledCount = words.filter((w) => w.enabled).length;
  return { total: words.length, enabled: enabledCount, words };
}

function formatPreview(words) {
  if (!words || words.length === 0) return "なし";
  const sample = words.slice(0, 12).join(", ");
  return `${sample}${words.length > 12 ? " ..." : ""}`;
}

function renderMetaView() {
  const importedMeta = localState.customHintMeta || null;
  const generatedAt = importedMeta?.generated_at || packagedVocabMeta?.generated_at;
  vocabUpdatedAtEl.textContent = generatedAt ? new Date(generatedAt).toLocaleString("ja-JP") : "未設定";
  vocabModeEl.textContent = importedMeta?.mode || (packagedVocabWords.length > 0 ? "packaged-json" : "未設定");

  const enabledCustom = enabledWordsFromItems(localState.vocabItems);
  const combinedCount = new Set([...packagedVocabWords, ...enabledCustom]).size;
  vocabCountEl.textContent = String(combinedCount);

  const previewWords = Array.isArray(importedMeta?.preview) ? importedMeta.preview : enabledCustom;
  vocabPreviewEl.textContent = formatPreview(previewWords);
}

function renderLearnedRules(data = {}) {
  const target = document.getElementById("learnedRuleCount");
  if (!target) return;
  const siteRules = data.siteRules && typeof data.siteRules === "object" ? data.siteRules : {};
  let count = 0;
  for (const rule of Object.values(siteRules)) {
    if (Array.isArray(rule?.protectedHints)) count += rule.protectedHints.length;
  }
  target.textContent = String(count);
}

function renderWordsPanel(categoryId, container, info, page) {
  container.textContent = "";
  if (info.total === 0) {
    const empty = document.createElement("div");
    empty.className = "emptyWords";
    empty.textContent = "該当語彙がありません";
    container.appendChild(empty);
    return;
  }

  const start = page * PAGE_SIZE;
  const pageItems = info.words.slice(start, start + PAGE_SIZE);
  for (const item of pageItems) {
    const label = document.createElement("label");
    label.className = "wordItem";

    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.checked = item.enabled;
    checkbox.dataset.word = item.word;
    checkbox.addEventListener("change", async () => {
      const target = localState.vocabItems.find((v) => v.word === item.word);
      if (!target) return;
      target.enabled = checkbox.checked;
      await persistVocabState({ mode: localState.customHintMeta?.mode || "manual", keepMeta: true });
      renderVocabArea();
    });

    const text = document.createElement("span");
    text.textContent = item.word;

    label.appendChild(checkbox);
    label.appendChild(text);
    container.appendChild(label);
  }
}

function renderCategoryItem(category, searchText, hideMisc) {
  const info = getCategoryStats(category.id, searchText, hideMisc);
  if (hideMisc && category.id === "misc") return null;

  const details = document.createElement("details");
  details.className = "categoryItem";
  details.dataset.category = category.id;
  details.open = localState.vocabUiState.expandedCategories.includes(category.id);

  const summary = document.createElement("summary");

  const left = document.createElement("div");
  left.className = "categoryLeft";

  const toggle = document.createElement("input");
  toggle.type = "checkbox";
  toggle.checked = info.total > 0 && info.enabled === info.total;
  toggle.indeterminate = info.enabled > 0 && info.enabled < info.total;
  toggle.addEventListener("click", (e) => e.stopPropagation());
  toggle.addEventListener("change", async () => {
    for (const item of localState.vocabItems) {
      if (item.category === category.id) {
        item.enabled = toggle.checked;
      }
    }
    await persistVocabState({ mode: localState.customHintMeta?.mode || "manual", keepMeta: true });
    renderVocabArea();
  });

  const title = document.createElement("span");
  title.className = "categoryTitle";
  title.textContent = category.label;

  left.appendChild(toggle);
  left.appendChild(title);

  const stat = document.createElement("span");
  stat.className = "categoryStat";
  stat.textContent = `${info.enabled}/${info.total}`;

  summary.appendChild(left);
  summary.appendChild(stat);

  const body = document.createElement("div");
  body.className = "categoryBody";

  const actions = document.createElement("div");
  actions.className = "categoryActions";
  const btnOn = document.createElement("button");
  btnOn.type = "button";
  btnOn.textContent = "このカテゴリを全ON";
  btnOn.addEventListener("click", async () => {
    for (const item of localState.vocabItems) {
      if (item.category === category.id) item.enabled = true;
    }
    await persistVocabState({ mode: localState.customHintMeta?.mode || "manual", keepMeta: true });
    renderVocabArea();
  });

  const btnOff = document.createElement("button");
  btnOff.type = "button";
  btnOff.className = "ghost";
  btnOff.textContent = "このカテゴリを全OFF";
  btnOff.addEventListener("click", async () => {
    for (const item of localState.vocabItems) {
      if (item.category === category.id) item.enabled = false;
    }
    await persistVocabState({ mode: localState.customHintMeta?.mode || "manual", keepMeta: true });
    renderVocabArea();
  });

  actions.appendChild(btnOn);
  actions.appendChild(btnOff);

  const wordsWrap = document.createElement("div");
  wordsWrap.className = "wordList";

  const pager = document.createElement("div");
  pager.className = "pager";
  const prev = document.createElement("button");
  prev.type = "button";
  prev.textContent = "前へ";
  const pageLabel = document.createElement("span");
  const next = document.createElement("button");
  next.type = "button";
  next.textContent = "次へ";

  const totalPages = Math.max(1, Math.ceil(info.total / PAGE_SIZE));
  const currentPage = Math.min(Math.max(0, pageByCategory[category.id] || 0), totalPages - 1);
  pageByCategory[category.id] = currentPage;

  pageLabel.textContent = `${currentPage + 1}/${totalPages}`;
  prev.disabled = currentPage === 0;
  next.disabled = currentPage >= totalPages - 1;

  prev.addEventListener("click", () => {
    pageByCategory[category.id] = Math.max(0, (pageByCategory[category.id] || 0) - 1);
    renderVocabArea();
  });

  next.addEventListener("click", () => {
    pageByCategory[category.id] = Math.min(totalPages - 1, (pageByCategory[category.id] || 0) + 1);
    renderVocabArea();
  });

  pager.appendChild(prev);
  pager.appendChild(pageLabel);
  pager.appendChild(next);

  body.appendChild(actions);
  body.appendChild(wordsWrap);
  body.appendChild(pager);

  details.appendChild(summary);
  details.appendChild(body);

  details.addEventListener("toggle", async () => {
    const set = new Set(localState.vocabUiState.expandedCategories);
    if (details.open) set.add(category.id);
    else set.delete(category.id);
    localState.vocabUiState.expandedCategories = Array.from(set);
    await chrome.storage.local.set({ vocabUiState: localState.vocabUiState });
    renderVocabArea();
  });

  if (details.open) {
    renderWordsPanel(category.id, wordsWrap, info, currentPage);
  }

  return details;
}

function renderVocabArea() {
  renderMetaView();

  const searchText = localState.vocabUiState.search || "";
  const hideMisc = Boolean(localState.vocabUiState.hideMisc);

  if (vocabSearchEl && vocabSearchEl.value !== searchText) {
    vocabSearchEl.value = searchText;
  }
  if (hideMiscEl) hideMiscEl.checked = hideMisc;

  categoryListEl.textContent = "";
  for (const category of CATEGORY_DEFS) {
    const item = renderCategoryItem(category, searchText, hideMisc);
    if (item) categoryListEl.appendChild(item);
  }
}

async function persistVocabState({ mode, keepMeta = false, sourceName = null, importedWords = null }) {
  const enabledWords = enabledWordsFromItems(localState.vocabItems);
  const currentMeta = keepMeta ? (localState.customHintMeta || {}) : {};

  const nextMeta = {
    ...currentMeta,
    generated_at: currentMeta.generated_at || new Date().toISOString(),
    imported_at: new Date().toISOString(),
    source: sourceName || currentMeta.source || "manual",
    mode: mode || currentMeta.mode || "manual",
    grouping: "semantic-category",
    topN: currentMeta.topN ?? null,
    minLen: currentMeta.minLen ?? null,
    maxLen: currentMeta.maxLen ?? null,
    preview: Array.isArray(importedWords) ? importedWords.slice(0, 12) : (currentMeta.preview || [])
  };

  localState.customHintMeta = nextMeta;

  await chrome.storage.local.set({
    customHintWords: enabledWords,
    customHintMeta: nextMeta,
    vocabItems: localState.vocabItems,
    vocabSources: localState.vocabSources,
    vocabUiState: localState.vocabUiState
  });
}

async function importPayload(payload, sourceName) {
  const sourceId = makeSourceId();
  localState.vocabItems = mergeWordsToVocabItems(localState.vocabItems, payload.words, sourceId);
  localState.vocabSources = [
    ...(localState.vocabSources || []),
    {
      id: sourceId,
      name: sourceName,
      importedAt: new Date().toISOString(),
      mode: payload.meta.mode,
      wordCount: payload.words.length
    }
  ];

  localState.customHintMeta = {
    ...payload.meta,
    source: sourceName,
    grouping: "semantic-category",
    preview: payload.preview || payload.words.slice(0, 12)
  };

  await persistVocabState({
    mode: payload.meta.mode,
    keepMeta: true,
    sourceName,
    importedWords: payload.preview || payload.words
  });

  renderVocabArea();
}

function buildLegacyItemsFromWords(words) {
  const normalized = normalizeWords(words);
  return normalized.map((word) => ({
    word,
    enabled: true,
    category: classifyWord(word),
    sourceIds: ["legacy"]
  }));
}

async function restore() {
  const data = await chrome.storage.local.get(DEFAULT_SETTINGS);
  applyValuesToInputs(data);
  renderLearnedRules(data);

  const customHintWords = normalizeWords(data.customHintWords);

  let vocabItems = Array.isArray(data.vocabItems)
    ? data.vocabItems.map(sanitizeVocabItem).filter(Boolean)
    : [];

  if (vocabItems.length === 0 && customHintWords.length > 0) {
    vocabItems = buildLegacyItemsFromWords(customHintWords);
  }

  if (vocabItems.length === 0) {
    vocabItems = buildLegacyItemsFromWords([]);
  }

  const vocabSources = Array.isArray(data.vocabSources) ? data.vocabSources : [];
  const vocabUiState = ensureUiState(data.vocabUiState);

  localState = {
    vocabItems,
    vocabSources,
    vocabUiState,
    customHintMeta: data.customHintMeta || null
  };

  // 互換データから新形式へ自動移行
  await chrome.storage.local.set({
    vocabItems: localState.vocabItems,
    vocabSources: localState.vocabSources,
    vocabUiState: localState.vocabUiState
  });

  renderVocabArea();
}

async function importFromText() {
  const textEl = document.getElementById("importText");
  const text = textEl?.value || "";
  if (!text.trim()) {
    showStatus("貼り付け内容が空です", true);
    return;
  }

  try {
    const payload = parseImportedFile(text, "pasted.txt");
    await importPayload(payload, "pasted.txt");
    showStatus(`語彙を取り込みました（${payload.meta.mode}）`);
  } catch (error) {
    showStatus(`インポート失敗: ${error.message}`, true);
  }
}

async function importFromFile(file) {
  if (!file) return;
  const text = await file.text();
  const payload = parseImportedFile(text, file.name || "input.txt");
  await importPayload(payload, file.name || "input.txt");
  showStatus(`ファイルを取り込みました（${payload.meta.mode}）`);
}

async function setFilteredWordsEnabled(enabled) {
  const query = (localState.vocabUiState.search || "").trim().toLowerCase();
  const hideMisc = Boolean(localState.vocabUiState.hideMisc);

  let targetCount = 0;
  for (const item of localState.vocabItems) {
    if (hideMisc && item.category === "misc") continue;
    if (query && !item.word.includes(query)) continue;
    item.enabled = enabled;
    targetCount += 1;
  }

  await persistVocabState({ mode: localState.customHintMeta?.mode || "manual", keepMeta: true });
  renderVocabArea();
  showStatus(`${targetCount}語を${enabled ? "ON" : "OFF"}にしました`);
}

function setupEvents() {
  for (const id of CHECKBOX_IDS) {
    document.getElementById(id)?.addEventListener("change", saveInputValues);
  }
  for (const id of NUMBER_IDS) {
    document.getElementById(id)?.addEventListener("change", saveInputValues);
  }
  document.getElementById("defaultRunMode")?.addEventListener("change", saveInputValues);

  document.getElementById("thresholdUp")?.addEventListener("click", async () => {
    const thresholdEl = document.getElementById("scoreThreshold");
    thresholdEl.value = String(clamp(Number(thresholdEl.value) + 1, 2, 12, DEFAULT_SETTINGS.scoreThreshold));
    await saveInputValues();
  });

  document.getElementById("thresholdDown")?.addEventListener("click", async () => {
    const thresholdEl = document.getElementById("scoreThreshold");
    thresholdEl.value = String(clamp(Number(thresholdEl.value) - 1, 2, 12, DEFAULT_SETTINGS.scoreThreshold));
    await saveInputValues();
  });

  document.getElementById("edgeStructThresholdUp")?.addEventListener("click", async () => {
    const targetEl = document.getElementById("edgeStructThreshold");
    targetEl.value = String(clamp(Number(targetEl.value) + 1, 3, 12, DEFAULT_SETTINGS.edgeStructThreshold));
    await saveInputValues();
  });

  document.getElementById("edgeStructThresholdDown")?.addEventListener("click", async () => {
    const targetEl = document.getElementById("edgeStructThreshold");
    targetEl.value = String(clamp(Number(targetEl.value) - 1, 3, 12, DEFAULT_SETTINGS.edgeStructThreshold));
    await saveInputValues();
  });

  document.getElementById("resetDefaults")?.addEventListener("click", async () => {
    await chrome.storage.local.set({
      ...DEFAULT_SETTINGS,
      vocabUiState: { expandedCategories: [], search: "", hideMisc: false },
      vocabItems: null,
      vocabSources: null,
      customHintWords: null,
      customHintMeta: null
    });
    await restore();
    showStatus("既定値に戻しました");
  });

  document.getElementById("clearLearnedRules")?.addEventListener("click", async () => {
    await chrome.storage.local.set({ siteRules: {} });
    renderLearnedRules({ siteRules: {} });
    showStatus("学習済み保護ヒントをクリアしました");
  });

  document.getElementById("importFromText")?.addEventListener("click", importFromText);

  document.getElementById("importFile")?.addEventListener("change", async (event) => {
    const file = event.target?.files?.[0];
    if (!file) return;
    try {
      await importFromFile(file);
    } catch (error) {
      showStatus(`インポート失敗: ${error.message}`, true);
    }
    event.target.value = "";
  });

  document.getElementById("clearImportedVocab")?.addEventListener("click", async () => {
    localState.vocabItems = [];
    localState.vocabSources = [];
    localState.customHintMeta = null;
    await chrome.storage.local.set({
      customHintWords: null,
      customHintMeta: null,
      vocabItems: [],
      vocabSources: []
    });
    renderVocabArea();
    showStatus("インポート語彙をクリアしました");
  });

  vocabSearchEl?.addEventListener("input", async () => {
    localState.vocabUiState.search = vocabSearchEl.value || "";
    await chrome.storage.local.set({ vocabUiState: localState.vocabUiState });
    renderVocabArea();
  });

  hideMiscEl?.addEventListener("change", async () => {
    localState.vocabUiState.hideMisc = Boolean(hideMiscEl.checked);
    await chrome.storage.local.set({ vocabUiState: localState.vocabUiState });
    renderVocabArea();
  });

  document.getElementById("searchOn")?.addEventListener("click", async () => {
    await setFilteredWordsEnabled(true);
  });

  document.getElementById("searchOff")?.addEventListener("click", async () => {
    await setFilteredWordsEnabled(false);
  });
}

document.addEventListener("DOMContentLoaded", async () => {
  await loadPackagedVocab();
  await restore();
  setupEvents();
});





