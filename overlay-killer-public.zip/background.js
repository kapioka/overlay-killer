const MENU_DISMISS = "ok-dismiss";
const MENU_UNDO = "ok-undo";
const MENU_OPTIONS = "ok-options";

async function sendMessageToTab(tabId, message) {
  if (!tabId) return;
  try {
    await chrome.tabs.sendMessage(tabId, message);
  } catch (_error) {
    // chrome:// など content script が存在しないページでは失敗する
  }
}

function createMenus() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: MENU_DISMISS,
      title: "広告/オーバーレイを削除（ワンプッシュ）",
      contexts: ["page"]
    });

    chrome.contextMenus.create({
      id: MENU_UNDO,
      title: "Undo（直前の非表示を戻す）",
      contexts: ["page"]
    });

    chrome.contextMenus.create({
      id: MENU_OPTIONS,
      title: "OverlayKiller 設定",
      contexts: ["page", "action"]
    });
  });
}

chrome.runtime.onInstalled.addListener(() => {
  createMenus();
});

chrome.runtime.onStartup.addListener(() => {
  createMenus();
});

chrome.action.onClicked.addListener(async (tab) => {
  await sendMessageToTab(tab?.id, { type: "OK_DISMISS" });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === MENU_OPTIONS) {
    chrome.runtime.openOptionsPage();
    return;
  }

  if (!tab?.id) return;

  if (info.menuItemId === MENU_DISMISS) {
    await sendMessageToTab(tab.id, { type: "OK_DISMISS" });
    return;
  }

  if (info.menuItemId === MENU_UNDO) {
    await sendMessageToTab(tab.id, { type: "OK_UNDO" });
  }
});
