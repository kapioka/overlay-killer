const MENU_DISMISS = "ok-dismiss";
const MENU_DISMISS_STRONG = "ok-dismiss-strong";
const MENU_PREVIEW = "ok-preview";
const MENU_CLEAR_PREVIEW = "ok-clear-preview";
const MENU_UNDO = "ok-undo";
const MENU_OPTIONS = "ok-options";

async function sendMessageToTab(tabId, message) {
  if (!tabId) return false;
  try {
    await chrome.tabs.sendMessage(tabId, message, { frameId: 0 });
    return true;
  } catch (_firstError) {
    // 拡張更新後も開いたままのタブでは、旧 content script が受信不能になる。
  }

  try {
    await chrome.scripting.executeScript({
      target: { tabId, frameIds: [0] },
      files: ["content.js"]
    });
    await chrome.tabs.sendMessage(tabId, message, { frameId: 0 });
    return true;
  } catch (_retryError) {
    // chrome:// など、content script を注入できないページでは失敗する。
    return false;
  }
}

function createMenus() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: MENU_DISMISS,
      title: "広告/オーバーレイを削除（標準）",
      contexts: ["page"]
    });

    chrome.contextMenus.create({
      id: MENU_DISMISS_STRONG,
      title: "広告/オーバーレイを強めに削除",
      contexts: ["page"]
    });

    chrome.contextMenus.create({
      id: MENU_PREVIEW,
      title: "削除候補を表示（プレビュー）",
      contexts: ["page"]
    });

    chrome.contextMenus.create({
      id: MENU_CLEAR_PREVIEW,
      title: "削除候補の表示を消す",
      contexts: ["page"]
    });

    chrome.contextMenus.create({
      id: MENU_UNDO,
      title: "Undo（直前の非表示を戻す）",
      contexts: ["page"]
    });

    chrome.contextMenus.create({
      id: MENU_OPTIONS,
      title: "OverlayKiller 設定",
      contexts: ["page", "action"]
    });
  });
}

chrome.runtime.onInstalled.addListener(() => {
  createMenus();
});

chrome.runtime.onStartup.addListener(() => {
  createMenus();
});

chrome.action.onClicked.addListener(async (tab) => {
  await sendMessageToTab(tab?.id, { type: "OK_DISMISS" });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === MENU_OPTIONS) {
    chrome.runtime.openOptionsPage();
    return;
  }

  if (!tab?.id) return;

  if (info.menuItemId === MENU_DISMISS) {
    await sendMessageToTab(tab.id, { type: "OK_DISMISS", mode: "standard" });
    return;
  }

  if (info.menuItemId === MENU_DISMISS_STRONG) {
    await sendMessageToTab(tab.id, { type: "OK_DISMISS", mode: "strong" });
    return;
  }

  if (info.menuItemId === MENU_PREVIEW) {
    await sendMessageToTab(tab.id, { type: "OK_DISMISS", mode: "preview" });
    return;
  }

  if (info.menuItemId === MENU_CLEAR_PREVIEW) {
    await sendMessageToTab(tab.id, { type: "OK_CLEAR_PREVIEW" });
    return;
  }

  if (info.menuItemId === MENU_UNDO) {
    await sendMessageToTab(tab.id, { type: "OK_UNDO" });
  }
});
